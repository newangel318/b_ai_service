### intent = faq.answer
faq_query: câu hỏi của khách viết lại đầy đủ, hiểu được mà không cần ngữ cảnh (ví dụ "Hạn mức chuyển tiền qua trợ lý Sami
trong một ngày là bao nhiêu?"). fields = {}, change_type = "none".

info_query (chỉ khi câu hỏi là về số liệu; nếu không, bỏ qua): {"topic", "term_months", "channel", "currency", "product", "advice"}.
- topic: deposit_rate (lãi suất tiết kiệm/tiền gửi), exchange_rate (tỷ giá ngoại tệ), gold (giá vàng), fee (biểu phí),
  card_feature (ưu đãi/tính năng thẻ), text (mọi câu hỏi khác).
- term_months: số tháng kỳ hạn nếu khách nêu (số nguyên). channel: "counter" (tại quầy) hoặc "online"; bỏ trống nếu không nêu.
- currency: mã ngoại tệ viết hoa (USD, EUR...). product: tên sản phẩm/thẻ khách nêu (ví dụ "thẻ visa platinum").
- advice = true khi khách nhờ tư vấn nên chọn gì ("nên gửi kỳ hạn nào", "có nên đầu tư"); ngược lại false.
Không tự điền con số; chỉ trích điều khách nói. Câu hỏi về số dư, hạn mức, giao dịch CỦA CHÍNH khách không thuộc intent này.
