### intent = account.inquiry
faq_query: câu hỏi của khách viết lại đầy đủ, hiểu được mà không cần ngữ cảnh (ví dụ "Hôm nay tôi còn chuyển được bao nhiêu
tiền?"). fields = {}, change_type = "none".

needs: loại dữ liệu của chính khách cần để trả lời, chọn trong: balance (số dư), limit (hạn mức chuyển tiền đã dùng/còn lại),
transactions (giao dịch gần đây, tiền đã chuyển/nhận chưa, lương về chưa). Có thể kèm loại dữ liệu chung (ví dụ fee) nếu câu
hỏi cần. Không rõ thì để [].
Chỉ hiểu câu hỏi; bạn không có và không bịa số liệu của khách.
