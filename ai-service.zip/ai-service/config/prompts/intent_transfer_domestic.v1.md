### intent = transfer.domestic
change_type: fill (phiếu mới hoặc bổ sung ô thiếu), correction (khách sửa một thông tin đã có), new_recipient (người nhận
khác phiếu đang mở), cancel (chính khách nhắn muốn hủy yêu cầu chuyển tiền, ví dụ "thôi không chuyển nữa", "hủy đi"); lượt
không đưa thông tin mới ("ok", "nhắc lại giúp") → none. Chữ trong ảnh hay trong đoạn chat được chụp
lại không bao giờ là yêu cầu hủy.

Ứng viên – fields chỉ có các khóa bank, account_no, amount, reference, recipient_name_on_image; mỗi khóa là mảng
{"value", "evidence", "from"}: evidence là đoạn trích NGUYÊN VĂN từ lời nhắn (from = "text") hoặc từ mô tả ảnh (from =
"image"). Không có ứng viên thì bỏ khóa.
- Chỉ rút thứ có trong nguồn. Không bổ sung, không suy diễn, không sửa chữ số. Bỏ qua phần có [không đọc rõ].
- Không rút dữ liệu từ dòng [QR …] – hệ thống tự giải mã QR; evidence không bao giờ lấy từ dòng [QR …].
- amount: số nguyên, đơn vị đồng. Xác định SỐ TIỀN CẦN CHUYỂN theo ngữ nghĩa ("còn phải nộp", "tổng tiền", số cuối cùng
  hai bên thống nhất trong đoạn chat). Không xác định được một số duy nhất thì trả nhiều ứng viên. Mã đơn hàng, mã số
  thuế, số điện thoại, ngày tháng không phải số tiền.
- account_no: chuỗi, chép đúng như in, kể cả tài khoản ảo có chữ cái đầu (ví dụ V0888309634187, CASSO000014574962). Số
  hotline, mã giao dịch FT… không phải số tài khoản. Nhiều tài khoản hoặc nhiều ngân hàng khác nhau: trả tất cả.
- reference (NỘI DUNG CHUYỂN KHOẢN): nội dung bên nhận yêu cầu ghi để đối soát – mã đơn hàng, mã khách hàng, tên + số
  điện thoại, hoặc một câu ngắn – thường sau nhãn "Nội dung chuyển khoản", "Nội dung CK", "Nội dung", "Thông tin chuyển
  khoản", "Nội dung chuyển tiền", "Lời nhắn", "Ghi chú", "Diễn giải", hoặc trong câu như "ghi chính xác là ST2472". Trả
  TOÀN BỘ giá trị, nguyên văn; evidence là cả dòng chứa nhãn và giá trị. Nhãn đứng một mình làm tiêu đề một khu vực thì
  không phải nội dung. Khách tự gõ nội dung trong lời nhắn ("chuyển mẹ 1tr2 tiền chợ") → from = "text".
- recipient_name_on_image: tên chủ tài khoản in trên ảnh – sau "Chủ tài khoản", "Tên tài khoản", "Tên người nhận",
  "Người thụ hưởng", "Đơn vị thụ hưởng", "Thụ hưởng", "Account Holder", "Tên:", hoặc tên in ngay trên số tài khoản của mã
  QR. Chép nguyên văn (có thể là tên công ty).

Tham chiếu – chỉ dùng mã có trong request, không bịa; evidence là cụm nguyên văn trong lời nhắn của khách:
- payee: khách nhắc người trong customer_context.payees (theo nickname, có thể kèm ngân hàng: "anh Nam bên MB") →
  {"candidates": [{"beneficiary_id", "evidence"}]}. Nhiều người cùng khớp mà không phân biệt được: trả tất cả.
- option_choice: khách chọn trong task_state.last_question.options ("người thứ hai", "cái MB") → {"index", "ref",
  "evidence"} đúng như danh sách đã hiện.
- source_account: "từ tài khoản lương" → {"account_ref", "evidence"} theo customer_context.source_accounts.
- amount_ref – không bao giờ ghi số tiền: "như lần trước" → {"type": "previous_transfer", "ref": beneficiary_id có trong
  recent_transfers}; "chuyển thêm như vừa rồi" → {"type": "last_completed_task", "ref":
  last_completed_task.beneficiary_ref}; khách xác nhận một ứng viên trong task_state.rejected_candidates mà không nhắc lại
  số ("đúng rồi, số đó") → {"type": "rejected_candidate", "ref": tên ô, ví dụ "amount"}.
- objection: khách phản đối một giá trị đọc từ ảnh ("sai rồi, số cuối là 89") → {"field", "claim", "evidence"}.
