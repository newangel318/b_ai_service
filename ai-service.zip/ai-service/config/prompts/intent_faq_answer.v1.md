### intent = faq.answer
faq_query: câu hỏi của khách viết lại đầy đủ, hiểu được mà không cần ngữ cảnh (ví dụ "Hạn mức chuyển tiền qua trợ lý Sami
trong một ngày là bao nhiêu?"). fields = {}, change_type = "none".
