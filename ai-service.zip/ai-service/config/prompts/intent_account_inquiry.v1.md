### intent = account.inquiry
account_query: {"topic", "account_ref", "count"}. fields = {}, change_type = "none".
- topic: limit (hạn mức còn lại của khách), balance (số dư), transactions (giao dịch gần đây/lần cuối), tx_status (một giao dịch
  đã thành công/chưa), incoming (tiền vào/lương về chưa), other (câu hỏi khác về tài khoản của chính khách).
- account_ref: chỉ khi khách nêu rõ tài khoản (ví dụ "tài khoản lương"), chép đúng lời khách; không đoán. Không nêu → bỏ trống.
- count: số giao dịch khách muốn xem (1-20) nếu có nêu.
Chỉ hiểu câu hỏi; bạn không có và không bịa số liệu của khách.
