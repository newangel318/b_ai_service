### intent = faq.answer
faq_query: câu hỏi của khách viết lại đầy đủ, hiểu được mà không cần ngữ cảnh; giữ đúng điều khách hỏi và điều khách loại trừ
(ví dụ sau "không phải phí thẻ, phí chuyển khoản bình thường á" → "Phí chuyển khoản từ tài khoản thanh toán là bao nhiêu?").
fields = {}, change_type = "none".

needs: 0–4 loại dữ liệu cần để trả lời, chọn trong danh sách sau; không chắc thì để [].
- product: sản phẩm tài khoản, tiết kiệm, vay, bảo hiểm, ngân hàng số
- card: thẻ (tín dụng, thanh toán, trả trước) – tính năng, ưu đãi, hoàn tiền, hạn mức thẻ, điều kiện
- promotion: chương trình khuyến mãi, ưu đãi đang có
- howto: cách dùng SacomPay/Sami, thủ tục, hỗ trợ
- fee: biểu phí (phí chuyển khoản, phí thẻ, phí dịch vụ)
- deposit_rate: lãi suất tiền gửi/tiết kiệm
- exchange_rate: tỷ giá ngoại tệ
- gold: giá vàng
Câu hỏi nhờ tư vấn (nên gửi kỳ hạn nào, có nên vay mua nhà, đầu tư gì, có nên mua vàng) vẫn là faq.answer; needs theo
sản phẩm khách nhắc tới (ví dụ deposit_rate, gold). Không tự điền con số; chỉ hiểu câu hỏi. Câu hỏi về số dư, hạn mức, giao dịch CỦA CHÍNH khách không thuộc intent này.
