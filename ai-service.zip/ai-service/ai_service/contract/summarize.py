"""POST /internal/ai/v1/summarize (spec 6): called separately for handoff or when history passes the threshold."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ai_service.contract.common import HistoryTurn, Meta, Model


class SummarizeRequest(Model):
    schema_version: Literal[1] = 1
    request_id: str
    purpose: Literal["handoff", "history"]
    turns: list[HistoryTurn] = Field(min_length=1)
    previous_summary: str | None = None


class SummarizeResponse(Model):
    schema_version: Literal[1] = 1
    request_id: str
    summary: str
    meta: Meta
    debug: dict[str, object] | None = None
