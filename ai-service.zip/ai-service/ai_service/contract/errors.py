"""Error body of group H (spec 5). chat-service maps codes to TB messages (IMP-41 (8))."""

from __future__ import annotations

from typing import Literal

from ai_service.contract.common import Model

ErrorCode = Literal["AI_BAD_REQUEST", "AI_UNAUTHORIZED", "AI_IMAGE_TOO_LARGE", "AI_OUTPUT_INVALID", "AI_RATE_LIMITED", "AI_UNAVAILABLE",
                    "AI_TIMEOUT"]


class ErrorDetail(Model):
    code: ErrorCode
    message: str
    retryable: bool
    request_id: str | None = None


class ErrorBody(Model):
    error: ErrorDetail
