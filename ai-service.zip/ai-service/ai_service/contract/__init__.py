"""Group H contract models (schema source of truth, published as contracts/ai-service.openapi.json)."""

from ai_service.contract.answer import AnswerPassage, AnswerRequest, AnswerResponse
from ai_service.contract.errors import ErrorBody, ErrorCode, ErrorDetail
from ai_service.contract.summarize import SummarizeRequest, SummarizeResponse
from ai_service.contract.understand import UnderstandRequest, UnderstandResponse

__all__ = ["AnswerPassage", "AnswerRequest", "AnswerResponse", "ErrorBody", "ErrorCode", "ErrorDetail", "SummarizeRequest", "SummarizeResponse",
           "UnderstandRequest", "UnderstandResponse"]
