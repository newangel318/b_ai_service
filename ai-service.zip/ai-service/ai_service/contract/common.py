"""Shared parts of the group H contract (chat-service -> ai-service). Pydantic is the schema source of truth (IMP-41)."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, StrictInt, StrictStr


class Model(BaseModel):
    """Every contract model rejects unknown fields: ai-service answers 400 to a request off the schema (spec 8)."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True, serialize_by_alias=True)


FieldName = Literal["bank", "account_no", "amount", "reference", "recipient_name_on_image"]
Language = Literal["vi", "en"]  # ISO 639-1; the language Sami replies in
MediaType = Literal["image/jpeg", "image/png", "image/webp"]


class Candidate(Model):
    value: StrictStr | StrictInt  # no coercion: True is not 1, "500" is not 500
    evidence: str  # verbatim phrase from message.text or an image description
    from_: Literal["text", "image"] = Field(alias="from")


def _typed_values(fields: dict[FieldName, list[Candidate]]) -> dict[FieldName, list[Candidate]]:
    """amount is a positive int (VND); every other field is text – an int account number would lose its leading zero."""
    for name, cands in fields.items():
        for c in cands:
            if name == "amount":
                if isinstance(c.value, bool) or not isinstance(c.value, int) or c.value <= 0:
                    raise ValueError(f"{name}: value must be a positive integer")
            elif not isinstance(c.value, str):
                raise ValueError(f"{name}: value must be a string")
    return fields


Fields = Annotated[dict[FieldName, list[Candidate]], AfterValidator(_typed_values)]


class ImageIn(Model):
    image_id: str
    media_type: MediaType
    data_base64: str  # held in memory only, never logged or written (U8)


class HistoryTurn(Model):
    role: Literal["user", "assistant"]
    text: str = ""
    image_id: str | None = None  # the description travels in task_state.image_descriptions
    draft_summary: str | None = None


class Tokens(Model):
    input: int = 0
    output: int = 0


class Meta(Model):
    prompt_version: str  # "<use_case>.v<N>", e.g. "understand.v1"
    models: dict[str, str] = Field(default_factory=dict)  # role -> deployment, e.g. {"vision": ..., "text": ...}
    latency_ms: dict[str, int] = Field(default_factory=dict)
    tokens: Tokens = Field(default_factory=Tokens)
    cost_usd: float | None = None  # from ai-service pricing.yaml, for the eval report (IMP-42)
    prompts: dict[str, str] = Field(default_factory=dict)  # every prompt file used: name -> version, for the eval report (IMP-46)
