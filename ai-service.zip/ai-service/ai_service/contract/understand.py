"""POST /internal/ai/v1/understand (Đặc tả /understand v0.3, sections 3 and 4)."""

from __future__ import annotations

from typing import Literal, get_args

from pydantic import Field, model_validator

from ai_service.contract.common import Fields, HistoryTurn, ImageIn, Language, Meta, Model

FieldState = Literal["filled", "verified", "missing", "error", "user_entered"]
OpenPhase = Literal["NEED_BENEFICIARY", "NEED_INFORMATION", "NEED_SOURCE_ACCOUNT", "NEED_CONFIRMATION"]


# ---------------------------------------------------------------- request
class QrParsed(Model):
    bank_bin: str | None = None
    bank_name: str | None = None
    account_no: str | None = None
    amount: int | None = None
    reference: str | None = None
    name: str | None = None


class QrIn(Model):
    """One QR decoded by chat-service (U5). ai-service only renders it as a labelled line."""

    index: int | None = Field(default=None, ge=1)  # optional: ai-service numbers QRs by position when absent (IMP-42)
    kind: Literal["VIETQR_TRANSFER", "EMVCO_OTHER", "GENERIC"]
    crc_valid: bool
    static: bool | None = None
    account_type: Literal["account", "card"] | None = None
    parsed: QrParsed | None = None
    generic_kind: Literal["digits", "phone", "url", "text"] | None = None
    text: str | None = None  # raw payload of a GENERIC QR


class ImageWithQr(ImageIn):
    qr: list[QrIn] = Field(default_factory=list)


class MessageIn(Model):
    text: str = ""
    image: ImageWithQr | None = None

    @model_validator(mode="after")
    def _text_or_image(self) -> MessageIn:
        if not self.text.strip() and self.image is None:
            raise ValueError("a message needs text or an image")
        return self


class TaskField(Model):
    value: str | int | None = None
    bank_code: str | None = None
    source: str | None = None
    state: FieldState = "missing"


class SourceAccountState(Model):
    account_no: str | None = None
    display: str | None = None
    state: FieldState = "missing"


class TaskFields(Model):
    bank: TaskField = Field(default_factory=TaskField)
    account_no: TaskField = Field(default_factory=TaskField)
    recipient_name: TaskField = Field(default_factory=TaskField)
    amount: TaskField = Field(default_factory=TaskField)
    reference: TaskField = Field(default_factory=TaskField)
    source_account: SourceAccountState = Field(default_factory=SourceAccountState)


class ShownOption(Model):
    index: int = Field(ge=1)
    label: str
    ref: str


class LastQuestion(Model):
    asked_fields: list[str] = Field(default_factory=list)
    text: str = ""
    options: list[ShownOption] = Field(default_factory=list)


class RejectedCandidate(Model):
    field: str
    value: str | int
    reason: str


class ImageDescriptionRef(Model):
    image_id: str
    description: str


class TaskState(Model):
    task_type: str
    draft_version: int = Field(ge=1)
    status: Literal["PENDING_INPUT", "PENDING_CONFIRM"]
    phase: OpenPhase  # read-only context, computed by chat-service
    fields: TaskFields = Field(default_factory=TaskFields)
    missing: list[str] = Field(default_factory=list)
    last_question: LastQuestion | None = None
    rejected_candidates: list[RejectedCandidate] = Field(default_factory=list)
    image_descriptions: list[ImageDescriptionRef] = Field(default_factory=list)


class History(Model):
    summary: str | None = None
    turns: list[HistoryTurn] = Field(default_factory=list)


class SourceAccountRef(Model):
    account_ref: str
    alias: str
    is_default: bool = False


class CustomerContext(Model):
    source_accounts: list[SourceAccountRef] = Field(default_factory=list)
    display_name: str | None = None


class UnderstandRequest(Model):
    schema_version: Literal[1] = 1
    request_id: str
    turn_id: str
    language: Language | None = None  # sent: reply in it whatever the customer typed; absent: ai-service detects it
    intents_enabled: list[str] = Field(min_length=1)
    message: MessageIn
    task_state: TaskState | None = None
    history: History = Field(default_factory=History)
    customer_context: CustomerContext = Field(default_factory=CustomerContext)


# ---------------------------------------------------------------- response
class ImageOut(Model):
    status: Literal["OK", "TIMEOUT", "ERROR", "NOT_A_DOCUMENT"]
    description: str | None = None  # QR data is chat-service's own decode (U5); the model's view of a QR is not returned (IMP-55)


class OptionChoice(Model):
    index: int | None = None
    ref: str | None = None
    evidence: str


class SourceAccountChoice(Model):
    account_ref: str
    evidence: str


class AmountRef(Model):
    type: Literal["rejected_candidate"]
    ref: str
    evidence: str


class Objection(Model):
    field: str
    claim: str
    evidence: str


Need = Literal["product", "card", "promotion", "howto", "fee", "deposit_rate", "exchange_rate", "gold", "balance", "limit",
               "transactions"]
NEEDS: tuple[str, ...] = get_args(Need)
MAX_NEEDS = 4


class Secondary(Model):
    intent: str
    query: str


class Safety(Model):
    prompt_attack: bool = False
    location: Literal["text", "image"] | None = None


class UnderstandResponse(Model):
    schema_version: Literal[1] = 1
    request_id: str
    image: ImageOut | None = None
    intent: str
    relation: Literal["new", "continue", "other"]
    change_type: Literal["fill", "correction", "new_recipient", "cancel", "none"]
    fields: Fields = Field(default_factory=dict)
    option_choice: OptionChoice | None = None
    source_account: SourceAccountChoice | None = None
    amount_ref: AmountRef | None = None
    objection: Objection | None = None
    language: Language = "vi"  # of the reply; faq_query and secondary[].query are always Vietnamese
    secondary: list[Secondary] = Field(default_factory=list)
    faq_query: str | None = None
    needs: list[Need] = Field(default_factory=list, max_length=MAX_NEEDS,
                              description="Kinds of data the answer needs (IMP-72): chat-service gathers them for /answer")
    safety: Safety = Field(default_factory=Safety)
    reason: str = ""  # short, for the turn log only
    meta: Meta
    debug: dict[str, object] | None = None  # v0 only, X-Debug-Trace (IMP-39)

    @model_validator(mode="after")
    def _image_failure_rules(self) -> UnderstandResponse:
        """TIMEOUT/ERROR: the whole turn fails, so no candidates at all (IMP-38). NOT_A_DOCUMENT: none from the image (IMP-44)."""
        status = self.image.status if self.image else "OK"
        if status in ("TIMEOUT", "ERROR") and (self.fields or self.option_choice or self.source_account or self.amount_ref):
            raise ValueError("a failed image read carries no candidates")
        if status == "NOT_A_DOCUMENT" and any(c.from_ == "image" for cands in self.fields.values() for c in cands):
            raise ValueError("NOT_A_DOCUMENT: no candidates from the image")
        return self
