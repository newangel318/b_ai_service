"""POST /internal/ai/v1/answer (TDD S07): answer a question from passages chat-service found in the knowledge base.
ai-service does not search: chat-service picks the passages, so it stays the one place that decides what data goes out."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ai_service.contract.common import HistoryTurn, Language, Meta, Model


class AnswerPassage(Model):
    passage_id: str = Field(min_length=1, max_length=120)
    title: str = ""
    heading: str = ""
    text: str = Field(min_length=1, max_length=4000)


class AnswerRequest(Model):
    schema_version: Literal[1] = 1
    request_id: str
    turn_id: str | None = None
    question: str = Field(min_length=1, max_length=1000, description="The customer's question, rewritten to stand alone (faq_query)")
    passages: list[AnswerPassage] = Field(min_length=1, max_length=32)
    history: list[HistoryTurn] = Field(default_factory=list, max_length=6, description="The last turns, for context only")
    language: Language | None = Field(default=None, description="Language to write the answer in; absent: the language the customer used")


class AnswerResponse(Model):
    schema_version: Literal[1] = 1
    request_id: str
    grounded: bool  # false: the passages do not answer the question – chat-service says it has no information
    answer: str = ""  # empty when not grounded
    used_passage_ids: list[str] = Field(default_factory=list)  # the passages the answer comes from (a subset of the request's)
    meta: Meta
    debug: dict[str, object] | None = None
