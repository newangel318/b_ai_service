"""Group H errors (spec 5). The API turns an ``AiError`` into ``{"error": {...}}`` with its HTTP status."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, ClassVar

from ai_service.contract.errors import ErrorBody, ErrorCode, ErrorDetail
from ai_service.ports import ModelError, ModelRateLimited, ModelTimeout


class AiError(Exception):
    status: ClassVar[int] = 503
    code: ClassVar[ErrorCode] = "AI_UNAVAILABLE"
    retryable: ClassVar[bool] = True
    request_id: str | None = None
    traced: bool = False  # its request_done line is written (IMP-48)

    def body(self, request_id: str | None) -> ErrorBody:
        return ErrorBody(error=ErrorDetail(code=self.code, message=str(self)[:500], retryable=self.retryable, request_id=request_id))


class BadRequest(AiError):
    status: ClassVar[int] = 400
    code: ClassVar[ErrorCode] = "AI_BAD_REQUEST"
    retryable: ClassVar[bool] = False


class Unauthorized(AiError):
    status: ClassVar[int] = 401
    code: ClassVar[ErrorCode] = "AI_UNAUTHORIZED"
    retryable: ClassVar[bool] = False


class ImageTooLarge(AiError):
    status: ClassVar[int] = 413
    code: ClassVar[ErrorCode] = "AI_IMAGE_TOO_LARGE"
    retryable: ClassVar[bool] = False


class OutputInvalid(AiError):
    status: ClassVar[int] = 422
    code: ClassVar[ErrorCode] = "AI_OUTPUT_INVALID"
    retryable: ClassVar[bool] = False


class RateLimited(AiError):
    status: ClassVar[int] = 429
    code: ClassVar[ErrorCode] = "AI_RATE_LIMITED"


class Unavailable(AiError):
    """503 – the defaults of AiError."""


class AiTimeout(AiError):
    status: ClassVar[int] = 504
    code: ClassVar[ErrorCode] = "AI_TIMEOUT"


def from_model_error(exc: ModelError) -> AiError:
    if isinstance(exc, ModelRateLimited):
        return RateLimited(str(exc) or "rate limited")
    if isinstance(exc, ModelTimeout):
        return AiTimeout(str(exc) or "model timeout")
    return Unavailable(str(exc) or "model unavailable")


def validation_summary(errors: Sequence[Mapping[str, Any]]) -> str:
    """``loc: msg`` per error, never the offending ``input`` (it can hold the image base64, U8)."""
    return "; ".join(f"{'.'.join(str(x) for x in e.get('loc', ()))}: {e.get('msg', '')}" for e in errors)[:500]
