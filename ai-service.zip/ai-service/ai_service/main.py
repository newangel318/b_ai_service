"""Composition root: the only module that imports adapters. Run: uvicorn ai_service.main:create --factory --port 8081"""

from __future__ import annotations

from fastapi import FastAPI

from ai_service.api.app import Services, create_app
from ai_service.capabilities import Capabilities, IntentCatalog, Pricing, PromptLibrary
from ai_service.config import Settings
from ai_service.logging_setup import configure_logging
from ai_service.ports import LlmClient, ShieldClient, VisionClient
from ai_service.understand.answer import AnswerService
from ai_service.understand.limits import Limits
from ai_service.understand.service import UnderstandService
from ai_service.understand.summarize import SummarizeService


def build_services(settings: Settings) -> Services:
    vision: VisionClient
    llm: LlmClient
    shield: ShieldClient | None = None
    if settings.llm_provider == "azure":
        from ai_service.adapters.azure import AzureLlmClient, AzureShieldClient, AzureVisionClient

        vision, llm = AzureVisionClient(settings), AzureLlmClient(settings)
        shield = AzureShieldClient(settings) if settings.content_safety_enabled else None
    else:
        from ai_service.adapters.fake import BundledBanks, FakeLlmClient, FakeVisionClient

        vision, llm = FakeVisionClient(settings.fake_sidecar_dirs), FakeLlmClient(BundledBanks.load())
    caps = Capabilities(vision, llm, PromptLibrary(settings.prompts_dir), Pricing(settings.pricing_file), shield)
    limits = Limits(settings.ai_total_timeout_s, settings.ai_max_image_base64_bytes)
    return Services(UnderstandService(caps, IntentCatalog(settings.intents_dir), limits), SummarizeService(caps, limits),
                    AnswerService(caps, limits))


def create() -> FastAPI:
    settings = Settings()
    configure_logging()
    return create_app(build_services(settings), settings)
