"""Environment settings of ai-service (one place; the composition root reads them)."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import AliasChoices, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

SERVICE_ROOT = Path(__file__).resolve().parents[1]  # ai-service/


class Settings(BaseSettings):
    # env_ignore_empty: "KEY=" from .env.example means "not set", so an empty …_TEXT does not hide …_EXTRACT
    model_config = SettingsConfigDict(env_file=None, extra="ignore", case_sensitive=False, env_ignore_empty=True)

    llm_provider: Literal["fake", "azure"] = "fake"
    ai_internal_key: str = ""  # X-Internal-Key; empty turns the check off (fake mode only, IMP-46 (6))
    ai_debug_trace: bool = False  # v0 only (IMP-39)
    ai_total_timeout_s: float = 15.0  # AI_TOTAL_TIMEOUT_S: one budget per call, image or not (IMP-55); chat-service waits longer
    ai_max_image_base64_bytes: int = 16 * 1024 * 1024  # v0 sends originals up to 12 MB (IMP-46 (3))

    prompts_dir: Path = SERVICE_ROOT / "config" / "prompts"
    pricing_file: Path = SERVICE_ROOT / "config" / "pricing.yaml"
    intents_dir: Path = SERVICE_ROOT / "config"  # intents.v<N>.yaml, highest version (IMP-48)

    azure_openai_endpoint: str = ""
    azure_openai_api_key: str = ""
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_deployment_vision: str = ""
    azure_openai_deployment_text: str = Field(
        default="", validation_alias=AliasChoices("azure_openai_deployment_text", "azure_openai_deployment_extract"))
    azure_openai_deployment_summary: str = ""
    content_safety_enabled: bool = False
    content_safety_endpoint: str = ""
    content_safety_key: str = ""

    fake_sidecar_dirs: list[Path] = Field(
        default_factory=lambda: [SERVICE_ROOT.parent / "testdata" / "images", SERVICE_ROOT.parent / "testdata" / "real"])

    @model_validator(mode="after")
    def _key_required_with_azure(self) -> Settings:
        if self.llm_provider == "azure" and not self.ai_internal_key:
            raise ValueError("AI_INTERNAL_KEY is required when LLM_PROVIDER=azure")
        return self
