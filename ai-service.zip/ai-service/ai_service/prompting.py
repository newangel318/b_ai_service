"""Prompt plumbing shared by the request renderer and the capabilities: customer, image and QR text is DATA (rule 6)
and can never open or close the tags that mark it as data."""

from __future__ import annotations

import re

DATA_TAGS = ("image_description", "user_text", "session_summary", "customer_context", "current_turn", "task_state", "earlier_images",
             "field", "question", "passage", "item")
_OUR_TAGS = re.compile(r"<(/?)(" + "|".join(DATA_TAGS) + ")", re.IGNORECASE)


def neutralize(text: str) -> str:
    """``</image_description>`` -> ``‹/image_description>``."""
    return _OUR_TAGS.sub(lambda m: f"‹{m.group(1)}{m.group(2)}", text)


def image_block(image_id: str, text: str) -> str:
    return f'<image_description id="{image_id.replace(chr(34), "")}">\n{neutralize(text)}\n</image_description>'
