"""``[QR n – …]`` label lines from chat-service's decoder results (U5). Same wording as v0 normalizer, pinned by
``contracts/fixtures/qr/vietqr.json`` (``qr_in`` -> ``description_line``). One QR = one line starting with ``[QR ``,
so chat-service can drop every QR line before the evidence check (spec 4.3)."""

from __future__ import annotations

from ai_service.contract.understand import QrIn, QrParsed

GENERIC_LABELS = {"digits": "dãy số", "phone": "số điện thoại", "url": "đường dẫn", "text": "văn bản"}


def _one_line(value: object) -> str:
    return " ".join(str(value).split())


def qr_line(qr: QrIn, position: int) -> str:
    n = qr.index or position
    if qr.kind == "VIETQR_TRANSFER":
        if not qr.crc_valid:
            return f"[QR {n} – VietQR, sai checksum, không dùng dữ liệu]"
        p = qr.parsed or QrParsed()
        mode = "tĩnh" if qr.static else "động"
        to = "thẻ" if qr.account_type == "card" else "tài khoản"
        label = "Số thẻ" if qr.account_type == "card" else "STK"
        amount = str(p.amount) if p.amount else "không có"
        reference = _one_line(p.reference) if p.reference else "không có"
        return (f"[QR {n} – VietQR chuyển tiền, {mode}, hợp lệ] BIN {_one_line(p.bank_bin)} · Tới: {to} · {label}: {_one_line(p.account_no)} · "
                f"Số tiền: {amount} · Nội dung: {reference}")
    if qr.kind == "EMVCO_OTHER":
        return f"[QR {n} – QR thanh toán khác]"
    return f"[QR {n} – QR thông thường, {GENERIC_LABELS.get(qr.generic_kind or 'text', 'văn bản')}] {_one_line(qr.text or '')}"


def with_qr_lines(description: str, qrs: list[QrIn]) -> str:
    lines = [qr_line(q, i) for i, q in enumerate(qrs, start=1)]
    return "\n".join([description, *lines]) if lines else description
