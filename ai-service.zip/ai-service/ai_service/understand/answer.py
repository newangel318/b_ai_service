"""POST /answer (TDD S07): one text call over the passages chat-service sent. The model proposes; this service keeps only
citations of passages that were sent, and an answer that cites none is not grounded."""

from __future__ import annotations

import asyncio

from pydantic import BaseModel, Field

from ai_service.capabilities import CallLog, Capabilities
from ai_service.contract.answer import AnswerRequest, AnswerResponse
from ai_service.errors import AiTimeout, from_model_error
from ai_service.ports import ModelError
from ai_service.prompting import neutralize
from ai_service.understand.limits import Limits


class AnswerModelOutput(BaseModel):
    grounded: bool
    answer: str = ""
    used_passage_ids: list[str] = Field(default_factory=list)


def render_answer(req: AnswerRequest) -> str:
    history = "\n".join(f"{'Khách hàng' if t.role == 'user' else 'Sami'}: {neutralize(t.text)}" for t in req.history if t.text)
    passages = "\n".join(
        f'<passage id="{p.passage_id.replace(chr(34), "")}">\n{neutralize(p.title)}{" › " + neutralize(p.heading) if p.heading else ""}\n'
        f"{neutralize(p.text)}\n</passage>" for p in req.passages)
    return (f"Lịch sử gần đây:\n{history}\n\n" if history else "") + f"<question>{neutralize(req.question)}</question>\n\n{passages}"


class AnswerService:
    def __init__(self, caps: Capabilities, limits: Limits) -> None:
        self._caps, self._limits = caps, limits

    async def answer(self, req: AnswerRequest, *, debug: bool = False) -> AnswerResponse:
        calls = CallLog(req.request_id)
        try:
            out = await asyncio.wait_for(self._caps.answer(render_answer(req), AnswerModelOutput, calls, req.language), self._limits.total_timeout_s)
        except TimeoutError as exc:
            raise AiTimeout("answer did not finish in time") from exc
        except ModelError as exc:
            raise from_model_error(exc) from exc
        sent = {p.passage_id for p in req.passages}
        used = [pid for pid in dict.fromkeys(out.used_passage_ids) if pid in sent]
        grounded = out.grounded and bool(used) and bool(out.answer.strip())
        return AnswerResponse(request_id=req.request_id, grounded=grounded, answer=out.answer.strip() if grounded else "",
                              used_passage_ids=used if grounded else [], meta=calls.meta(self._caps.prompt_version("answer")),
                              debug=calls.debug() if debug else None)
