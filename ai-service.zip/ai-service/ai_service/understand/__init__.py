"""Group H use cases: prompt assembly from the request and post-processing of model output (no business decisions)."""
