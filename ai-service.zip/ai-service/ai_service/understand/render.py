"""Turns a group-H request into the messages of the text call. Everything from the customer, images and chat-service's
state is DATA inside tags it cannot open or close (rule 6)."""

from __future__ import annotations

import json

from ai_service.contract.common import HistoryTurn
from ai_service.contract.understand import TaskState, UnderstandRequest
from ai_service.ports import ChatMessage
from ai_service.prompting import image_block, neutralize


def _json(data: object) -> str:
    return neutralize(json.dumps(data, ensure_ascii=False, indent=1))


def render_task_state(task: TaskState | None) -> str:
    if task is None:
        return "<task_state>none</task_state>"
    out = f"<task_state>\n{_json(task.model_dump(mode='json', exclude={'image_descriptions'}, exclude_none=True))}\n</task_state>"
    if task.image_descriptions:
        out += "\n<earlier_images>\n" + "\n".join(image_block(d.image_id, d.description) for d in task.image_descriptions) + "\n</earlier_images>"
    return out


def render_current_turn(text: str, image_id: str | None, description: str | None) -> str:
    parts = [f"<user_text>{neutralize(text)}</user_text>"] if text else []
    if image_id and description is not None:
        parts.append(image_block(image_id, description))
    return "<current_turn>\n" + ("\n".join(parts) or "<user_text></user_text>") + "\n</current_turn>"


def _history(req: UnderstandRequest) -> list[ChatMessage]:
    out: list[ChatMessage] = []
    if req.history.summary:
        out += [ChatMessage("user", f"<session_summary>\n{neutralize(req.history.summary)}\n</session_summary>"),
                ChatMessage("assistant", "Đã ghi nhận tóm tắt.")]
    for t in req.history.turns:
        if t.role == "user":
            ref = f'\n<image_ref id="{t.image_id.replace(chr(34), "")}"/>' if t.image_id else ""
            out.append(ChatMessage("user", f"<user_text>{neutralize(t.text)}</user_text>{ref}"))
        else:
            out.append(ChatMessage("assistant", t.text + (f"\n[Phiếu: {neutralize(t.draft_summary)}]" if t.draft_summary else "")))
    return out


def render_messages(req: UnderstandRequest, description: str | None) -> list[ChatMessage]:
    """``description`` is the new image's text with QR lines already appended (None when the turn has no new image)."""
    image_id = req.message.image.image_id if req.message.image else None
    final = "\n".join([
        f"<customer_context>\n{_json(req.customer_context.model_dump(mode='json', exclude_none=True))}\n</customer_context>",
        render_task_state(req.task_state),
        render_current_turn(req.message.text, image_id, description),
    ])
    return [*_history(req), ChatMessage("user", final)]


def render_turns(turns: list[HistoryTurn], previous_summary: str | None) -> str:
    lines = [f"<session_summary>\n{neutralize(previous_summary)}\n</session_summary>"] if previous_summary else []
    for t in turns:
        who = "Khách hàng" if t.role == "user" else "Sami"
        extra = (f" [ảnh {t.image_id}]" if t.image_id else "") + (f" [phiếu: {neutralize(t.draft_summary)}]" if t.draft_summary else "")
        lines.append(f"{who}: {neutralize(t.text)}{extra}")
    return "\n".join(lines)
