"""POST /understand: one HTTP call per turn (U6) – a vision call when the turn has a new image, then one text call.
Intent first (IMP-47): the text model classifies the turn from image + text + history, then fills only that intent's part;
this service keeps only what the chosen intent may carry. Proposes only (U2): no verification, no phase, no copy (U3)."""

from __future__ import annotations

import asyncio
from typing import Literal

from ai_service.capabilities import CallLog, Capabilities, IntentCatalog
from ai_service.contract.understand import ImageOut, QrIn, Safety, UnderstandRequest, UnderstandResponse
from ai_service.errors import AiTimeout, BadRequest, from_model_error
from ai_service.logging_setup import get_logger
from ai_service.ports import ModelError, ModelTimeout
from ai_service.understand.language import resolve_language
from ai_service.understand.limits import Limits, decode_image
from ai_service.understand.model_output import UnderstandModelOutput
from ai_service.understand.qr_lines import with_qr_lines
from ai_service.understand.render import render_messages

log = get_logger("understand")
REF_NAMES = ("option_choice", "source_account", "amount_ref", "objection", "faq_query", "needs")


def image_status(image_relevant: bool | None, qrs: list[QrIn]) -> Literal["OK", "NOT_A_DOCUMENT"]:
    """IMP-44, IMP-47: judged against the chosen intent by the text model; a VietQR decoded by chat-service is transfer data."""
    irrelevant = image_relevant is False and not any(q.kind == "VIETQR_TRANSFER" for q in qrs)
    return "NOT_A_DOCUMENT" if irrelevant else "OK"


class UnderstandService:
    def __init__(self, caps: Capabilities, intents: IntentCatalog, limits: Limits) -> None:
        self._caps, self._intents, self._limits = caps, intents, limits
        self._known = frozenset(intents.ids())
        for section in intents.sections(intents.ids()):  # a registry entry without its prompt fails here, not on every turn
            caps.prompt_version(section)

    def _image_failed(self, req: UnderstandRequest, status: Literal["TIMEOUT", "ERROR"], calls: CallLog, debug: bool) -> UnderstandResponse:
        """IMP-38: the whole turn fails – no candidates, no text call; chat-service answers TB-12."""
        log.warning("image_read_failed", request_id=req.request_id, turn_id=req.turn_id, status=status)
        return UnderstandResponse(request_id=req.request_id, image=ImageOut(status=status), intent="unknown", relation="other",
                                  change_type="none", language=req.language or "vi", meta=calls.meta(self._caps.prompt_version("understand")),
                                  debug=calls.debug() if debug else None)

    async def understand(self, req: UnderstandRequest, *, debug: bool = False) -> UnderstandResponse:
        unknown = [i for i in req.intents_enabled if i not in self._known]
        if unknown:  # IMP-57: chat-service enabled an intent this registry cannot describe – a config drift, not a turn
            raise BadRequest(f"intents_enabled has ids not in {self._intents.version}: {', '.join(unknown)}")
        calls = CallLog(req.request_id)
        budget = self._limits.budget()
        description: str | None = None
        img = req.message.image
        if img is not None:
            data = decode_image(img.data_base64, self._limits)
            try:
                seen = await asyncio.wait_for(self._caps.describe_image(data, img.media_type, calls), budget.left())
            except (TimeoutError, ModelTimeout):
                return self._image_failed(req, "TIMEOUT", calls, debug)
            except Exception:  # noqa: BLE001 – any vision failure is an image read error (IMP-38)
                log.exception("vision_failed", request_id=req.request_id)
                return self._image_failed(req, "ERROR", calls, debug)
            description = with_qr_lines(seen.strip(), img.qr)

        messages = render_messages(req, description)
        enabled = req.intents_enabled
        try:
            safety, out = await asyncio.gather(
                self._caps.shield(req.message.text, [description] if description else []),
                asyncio.wait_for(self._caps.understand(messages, self._intents.describe(enabled), self._intents.sections(enabled),
                                                       UnderstandModelOutput, calls, registry=self._intents.version),
                               budget.left()),
            )
        except TimeoutError as exc:
            raise AiTimeout(f"no answer within the {budget.total_s}s budget") from exc
        except ModelError as exc:
            raise from_model_error(exc) from exc

        intent, reason = out.intent, out.reason
        if intent not in enabled:  # IMP-46 (5)
            intent, reason = "unknown", f"intent {out.intent!r} is not enabled"
        spec = self._intents.spec(intent)  # classification guard: only what the chosen intent may carry (IMP-47)
        out = out.model_copy(update={name: [] if name == "needs" else None for name in REF_NAMES if name not in spec.refs})
        fields = {k: v for k, v in out.fields.items() if k in spec.slots}
        image: ImageOut | None = None
        if img is not None:
            image = ImageOut(status=image_status(out.image_relevant, img.qr), description=description)
            if image.status == "NOT_A_DOCUMENT":  # IMP-44: only the image's candidates go
                fields = {k: kept for k, v in fields.items() if (kept := [c for c in v if c.from_ != "image"])}

        location: Literal["text", "image"] | None = "text" if safety.text_attack else "image" if safety.document_attack else None
        res = UnderstandResponse(
            request_id=req.request_id, image=image, intent=intent, relation=out.relation,
            change_type=out.change_type if spec.slots else "none", fields=fields,
            option_choice=out.option_choice, source_account=out.source_account, amount_ref=out.amount_ref,
            objection=out.objection, faq_query=out.faq_query, needs=out.needs,
            secondary=out.secondary, language=resolve_language(req.language, out.language), safety=Safety(prompt_attack=location is not None, location=location), reason=reason,
            meta=calls.meta(self._caps.prompt_version("understand")), debug=calls.debug() if debug else None)
        log.info("understand", request_id=req.request_id, turn_id=req.turn_id, intent=res.intent,
                 image_status=image.status if image else None, fields=sorted(res.fields), prompt_attack=res.safety.prompt_attack,
                 tokens_in=res.meta.tokens.input, tokens_out=res.meta.tokens.output, latency_ms=res.meta.latency_ms.get("total"))
        return res
