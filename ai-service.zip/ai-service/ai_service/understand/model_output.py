"""What the text model returns (structured output). The service adds request_id, image, safety and meta, and never trusts
the model for them.

Lenient on purpose (final review of P2): a slip in one optional part drops that part, not the turn. A broken candidate or
reference is dropped, never coerced – the field stays empty and Sami asks (rule 2). Only an output without ``intent`` (or
not JSON at all) is invalid and retried.
"""

from __future__ import annotations

from typing import Any, Literal, get_args

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from ai_service.contract.common import Candidate, FieldName
from ai_service.contract.understand import (
    MAX_NEEDS,
    NEEDS,
    AmountRef,
    Objection,
    OptionChoice,
    Secondary,
    SourceAccountChoice,
)
from ai_service.errors import validation_summary
from ai_service.logging_setup import get_logger

log = get_logger("model_output")
FIELD_NAMES = frozenset(get_args(FieldName))
RELATIONS = ("new", "continue", "other")
CHANGE_TYPES = ("fill", "correction", "new_recipient", "cancel", "none")


def _known_keys(model: type[BaseModel], raw: dict[str, Any]) -> dict[str, Any]:
    names = {f.alias or n for n, f in model.model_fields.items()} | set(model.model_fields)
    return {k: v for k, v in raw.items() if k in names}


def _part[M: BaseModel](model: type[M], raw: Any, where: str) -> M | None:
    """One optional part of the output, or None (logged) when it does not fit the contract."""
    if raw is None:
        return None
    try:
        return model.model_validate(_known_keys(model, raw) if isinstance(raw, dict) else raw)
    except ValidationError as exc:
        log.info("model_output_part_dropped", part=where, error=validation_summary(exc.errors()))
        return None


def _candidate_ok(name: str, c: Candidate) -> bool:
    if name == "amount":
        return isinstance(c.value, int) and not isinstance(c.value, bool) and c.value > 0
    return isinstance(c.value, str)


def lenient_fields(raw: Any) -> dict[FieldName, list[Candidate]]:
    out: dict[FieldName, list[Candidate]] = {}
    if not isinstance(raw, dict):
        return out
    for name, cands in raw.items():
        if name not in FIELD_NAMES or not isinstance(cands, list):
            continue
        kept = [c for c in (_part(Candidate, x, f"fields.{name}") for x in cands) if c is not None and _candidate_ok(name, c)]
        if kept:
            out[name] = kept
    return out


class UnderstandModelOutput(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    intent: str
    relation: Literal["new", "continue", "other"] = "new"
    change_type: Literal["fill", "correction", "new_recipient", "cancel", "none"] = "none"
    fields: dict[FieldName, list[Candidate]] = Field(default_factory=dict)
    option_choice: OptionChoice | None = None
    source_account: SourceAccountChoice | None = None
    amount_ref: AmountRef | None = None
    objection: Objection | None = None
    secondary: list[Secondary] = Field(default_factory=list)
    faq_query: str | None = None
    language: str | None = None  # "vi" or any other language code; resolve_language maps it
    needs: list[str] = Field(default_factory=list)
    image_relevant: bool | None = None  # the new image carries information for the chosen intent (IMP-47)
    reason: str = ""

    @field_validator("relation", mode="before")
    @classmethod
    def _relation(cls, v: Any) -> Any:
        return v if v in RELATIONS else "new"

    @field_validator("change_type", mode="before")
    @classmethod
    def _change_type(cls, v: Any) -> Any:
        return v if v in CHANGE_TYPES else "none"

    @field_validator("fields", mode="before")
    @classmethod
    def _fields(cls, v: Any) -> Any:
        return lenient_fields(v)

    @field_validator("option_choice", mode="before")
    @classmethod
    def _option_choice(cls, v: Any) -> Any:
        return _part(OptionChoice, v, "option_choice")

    @field_validator("source_account", mode="before")
    @classmethod
    def _source_account(cls, v: Any) -> Any:
        return _part(SourceAccountChoice, v, "source_account")

    @field_validator("amount_ref", mode="before")
    @classmethod
    def _amount_ref(cls, v: Any) -> Any:
        return _part(AmountRef, v, "amount_ref")

    @field_validator("objection", mode="before")
    @classmethod
    def _objection(cls, v: Any) -> Any:
        return _part(Objection, v, "objection")

    @field_validator("secondary", mode="before")
    @classmethod
    def _secondary(cls, v: Any) -> Any:
        return [s for s in (_part(Secondary, x, "secondary") for x in v) if s is not None] if isinstance(v, list) else []

    @field_validator("faq_query", mode="before")
    @classmethod
    def _faq_query(cls, v: Any) -> Any:
        return v if isinstance(v, str) else None

    @field_validator("language", mode="before")
    @classmethod
    def _language(cls, v: Any) -> Any:
        return v if isinstance(v, str) else None

    @field_validator("needs", mode="before")
    @classmethod
    def _needs(cls, v: Any) -> Any:
        """Known values only, in order, without duplicates, at most MAX_NEEDS (an unknown kind is dropped, not the turn)."""
        if not isinstance(v, list):
            return []
        return list(dict.fromkeys(x for x in v if isinstance(x, str) and x in NEEDS))[:MAX_NEEDS]

    @field_validator("image_relevant", mode="before")
    @classmethod
    def _image_relevant(cls, v: Any) -> Any:
        return v if isinstance(v, bool) else None

    @field_validator("reason", mode="before")
    @classmethod
    def _reason(cls, v: Any) -> Any:
        return v if isinstance(v, str) else ""
