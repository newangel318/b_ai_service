"""Parameters of the group-H use cases (IMP-46 (3), IMP-55) and the image check that runs before any model call."""

from __future__ import annotations

import base64
import binascii
import time
from dataclasses import dataclass, field

from ai_service.errors import BadRequest, ImageTooLarge


@dataclass(frozen=True)
class Limits:
    total_timeout_s: float = 15.0  # one budget per call, image or not (IMP-55); tests and measurements set their own
    max_image_base64_bytes: int = 16 * 1024 * 1024

    def budget(self) -> Budget:
        return Budget(self.total_timeout_s)


@dataclass
class Budget:
    """The time left of one call's total budget: every model call of the request waits at most what is left."""

    total_s: float
    _deadline: float = field(init=False)

    def __post_init__(self) -> None:
        self._deadline = time.monotonic() + self.total_s

    def left(self) -> float:
        return max(0.0, self._deadline - time.monotonic())


def decode_image(data_base64: str, limits: Limits) -> bytes:
    """Held in memory only (U8). Too large -> 413; not base64 or empty -> 400."""
    if len(data_base64) > limits.max_image_base64_bytes:
        raise ImageTooLarge(f"image is {len(data_base64)} base64 bytes, limit {limits.max_image_base64_bytes}")
    try:
        data = base64.b64decode(data_base64, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise BadRequest("data_base64 is not valid base64") from exc
    if not data:
        raise BadRequest("data_base64 is empty")
    return data
