"""The language Sami replies in (spec: multi-language). A language chat-service sends wins; else what the model saw in the
customer's words; else Vietnamese. Any language that is not Vietnamese is English."""

from __future__ import annotations

from ai_service.contract.common import Language


def resolve_language(requested: Language | None, detected: str | None) -> Language:
    if requested is not None:
        return requested
    if not detected:
        return "vi"
    return "vi" if detected.strip().lower() == "vi" else "en"
