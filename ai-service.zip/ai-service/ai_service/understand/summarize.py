"""POST /summarize (spec 6): called separately, for a handoff or when chat-service's history passes its threshold."""

from __future__ import annotations

import asyncio

from ai_service.capabilities import CallLog, Capabilities
from ai_service.contract.summarize import SummarizeRequest, SummarizeResponse
from ai_service.errors import AiTimeout, from_model_error
from ai_service.ports import ModelError
from ai_service.understand.limits import Limits
from ai_service.understand.render import render_turns


class SummarizeService:
    def __init__(self, caps: Capabilities, limits: Limits) -> None:
        self._caps, self._limits = caps, limits

    async def summarize(self, req: SummarizeRequest, *, debug: bool = False) -> SummarizeResponse:
        calls = CallLog(req.request_id)
        try:
            text = await asyncio.wait_for(self._caps.summarize(render_turns(req.turns, req.previous_summary), req.purpose, calls),
                                          self._limits.total_timeout_s)
        except TimeoutError as exc:
            raise AiTimeout("summary did not finish in time") from exc
        except ModelError as exc:
            raise from_model_error(exc) from exc
        return SummarizeResponse(request_id=req.request_id, summary=text, meta=calls.meta(self._caps.prompt_version("summarize")),
                                 debug=calls.debug() if debug else None)
