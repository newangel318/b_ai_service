"""The only module that calls model clients. No business decisions: it builds prompts from files, calls, validates
structured output (one retry), and records use case, prompt version, deployment, tokens, latency and cost per call."""

from __future__ import annotations

import asyncio
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TypeVar

import yaml
from pydantic import BaseModel, ValidationError

from ai_service.contract.common import Language, Meta, Tokens
from ai_service.errors import OutputInvalid, validation_summary
from ai_service.logging_setup import get_logger
from ai_service.ports import ChatMessage, LlmClient, ModelError, ModelResult, ShieldClient, ShieldResult, VisionClient

log = get_logger("capabilities")
T = TypeVar("T", bound=BaseModel)

USE_CASES: dict[str, tuple[str, str]] = {  # use case -> (meta role, pricing key)
    "sami.understand_image": ("vision", "vision"),
    "sami.understand": ("text", "text"),
    "sami.summarize": ("text", "summary"),
    "sami.answer": ("text", "text"),
}
PURPOSE_TEXT = {"handoff": "để chuyển cho nhân viên hỗ trợ", "history": "để thay cho phần lịch sử cũ"}
RETRY_HINT = "Kết quả trước không phải JSON hợp lệ theo schema. Chỉ trả về JSON hợp lệ."


@dataclass
class CallRecord:
    use_case: str
    prompt_version: str
    deployment: str
    input_tokens: int
    output_tokens: int
    latency_ms: int
    cost_usd: float
    ok: bool
    error: str | None = None
    messages: list[dict[str, str]] = field(default_factory=list)
    raw_output: str = ""
    prompt_parts: list[str] = field(default_factory=list)  # every prompt file in the call, e.g. core + intent sections


@dataclass
class CallLog:
    """Model calls of one group-H request; becomes ``meta`` and, on request, ``debug``."""

    request_id: str
    started: float = field(default_factory=time.perf_counter)
    calls: list[CallRecord] = field(default_factory=list)

    def meta(self, prompt_version: str) -> Meta:
        models: dict[str, str] = {}
        prompts: dict[str, str] = {}
        latency: dict[str, int] = {}
        for c in self.calls:
            role = USE_CASES[c.use_case][0]
            if c.deployment:
                models[role] = c.deployment
            for version in c.prompt_parts or [c.prompt_version]:
                prompts[version.rsplit(".v", 1)[0]] = version
            key = "vision" if role == "vision" else "llm"
            latency[key] = latency.get(key, 0) + c.latency_ms
        latency["total"] = int((time.perf_counter() - self.started) * 1000)
        return Meta(prompt_version=prompt_version, models=models, latency_ms=latency,
                    tokens=Tokens(input=sum(c.input_tokens for c in self.calls), output=sum(c.output_tokens for c in self.calls)),
                    cost_usd=round(sum(c.cost_usd for c in self.calls), 6), prompts=prompts)

    def debug(self) -> dict[str, object]:
        return {"calls": [{"use_case": c.use_case, "prompt_version": c.prompt_version, "deployment": c.deployment, "ok": c.ok,
                           "error": c.error, "messages": c.messages, "raw_output": c.raw_output} for c in self.calls]}


def latest_version(directory: Path, name: str, suffix: str) -> Path:
    """``<name>.v<N><suffix>`` with the highest N (prompts and the intent registry, IMP-48)."""
    files = [p for p in directory.glob(f"{name}.v*{suffix}") if re.fullmatch(rf"{re.escape(name)}\.v\d+{re.escape(suffix)}", p.name)]
    if not files:
        raise FileNotFoundError(f"not found: {name}.v<N>{suffix}")
    return max(files, key=lambda p: int(p.name.removesuffix(suffix).rsplit(".v", 1)[1]))


REPLY_LANGUAGE: dict[str | None, str] = {
    "vi": 'Viết tiếng Việt, xưng "Sami", gọi khách là "Quý khách"; ngắn gọn, tối đa khoảng 120 từ. Văn bản thuần, có thể dùng dòng bắt đầu '
          'bằng "• " cho danh sách. Không nêu mã đoạn trong câu trả lời. Không mở đầu bằng "Sami xin thông tin" hay "Sami xin cung cấp".',
    "en": 'Write the answer in English, as Sami, addressing the customer as "you"; short, at most about 120 words. Plain text; '
          'lines starting with "• " for lists. Do not mention passage ids. The passages are Vietnamese: translate, never add facts.',
    None: "Viết bằng ngôn ngữ khách dùng trong lịch sử gần đây (tiếng Việt hoặc tiếng Anh), theo đúng quy tắc trình bày ở trên.",
}


class PromptLibrary:
    """``config/prompts/<use_case>.v<N>.md``; the highest version wins."""

    def __init__(self, directory: Path) -> None:
        self._dir = directory

    def get(self, name: str, **placeholders: str) -> tuple[str, str]:
        latest = latest_version(self._dir, name, ".md")
        text = latest.read_text(encoding="utf-8").strip()
        for k, v in placeholders.items():
            text = text.replace("{{" + k + "}}", v)
        return text, latest.name.removesuffix(".md")


class Pricing:
    def __init__(self, path: Path | None) -> None:
        self._table: dict[str, dict[str, float]] = {}
        if path and path.exists():
            self._table = yaml.safe_load(path.read_text(encoding="utf-8")) or {}

    def cost(self, key: str, input_tokens: int, output_tokens: int) -> float:
        p = self._table.get(key, {})
        return (input_tokens * p.get("input_per_1m", 0.0) + output_tokens * p.get("output_per_1m", 0.0)) / 1_000_000


@dataclass(frozen=True)
class IntentSpec:
    intent_id: str
    description: str = ""
    section: str | None = None  # step-2 prompt file; None = nothing to fill
    slots: frozenset[str] = frozenset()  # keys of `fields` this intent may fill
    refs: frozenset[str] = frozenset()  # option_choice, source_account, amount_ref, objection, faq_query, needs


class IntentCatalog:
    """config/intents.v<N>.yaml (highest N): how to recognise each intent and what it may fill (IMP-47). Versioned like the
    prompts because step 1 of the understand prompt is built from it (IMP-48). chat-service decides which are enabled."""

    def __init__(self, config_dir: Path) -> None:
        path = latest_version(config_dir, "intents", ".yaml")
        self.version = path.name.removesuffix(".yaml")
        items: list[dict[str, Any]] = yaml.safe_load(path.read_text(encoding="utf-8")) or []
        self._specs = {str(i["intent_id"]): IntentSpec(str(i["intent_id"]), str(i.get("description", "")), i.get("section"),
                                                         frozenset(i.get("slots", [])), frozenset(i.get("refs", []))) for i in items}

    def spec(self, intent_id: str) -> IntentSpec:
        return self._specs.get(intent_id, IntentSpec(intent_id))

    def describe(self, enabled: list[str]) -> str:
        return "\n".join(f"- {i}: {d}" if (d := self.spec(i).description) else f"- {i}" for i in enabled)

    def ids(self) -> list[str]:
        return list(self._specs)

    def sections(self, enabled: list[str]) -> list[str]:
        return [s for i in enabled if (s := self.spec(i).section)]


def _json_text(text: str) -> str:
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    return (m.group(1) if m else text).strip()


class Capabilities:
    def __init__(self, vision: VisionClient, llm: LlmClient, prompts: PromptLibrary, pricing: Pricing, shield: ShieldClient | None = None) -> None:
        self._vision, self._llm, self._prompts, self._pricing, self._shield = vision, llm, prompts, pricing, shield

    def prompt_version(self, name: str) -> str:
        return self._prompts.get(name)[1]

    # ------------------------------------------------------------------ plumbing
    def _record(self, calls: CallLog, use_case: str, version: str, res: ModelResult | None, started: float, *, ok: bool,
                error: str | None = None, messages: list[dict[str, str]] | None = None, parts: list[str] | None = None) -> None:
        in_t, out_t = (res.usage.input_tokens, res.usage.output_tokens) if res else (0, 0)
        latency = res.latency_ms if res and res.latency_ms else int((time.perf_counter() - started) * 1000)
        cost = self._pricing.cost(USE_CASES[use_case][1], in_t, out_t)
        calls.calls.append(CallRecord(use_case, version, res.deployment if res else "", in_t, out_t, latency, cost, ok, error,
                                      messages or [], res.text if res else "", parts or []))
        log.info("model_call", request_id=calls.request_id, use_case=use_case, prompt_version=version, input_tokens=in_t,
                 output_tokens=out_t, latency_ms=latency, ok=ok, error=error)

    async def _vision_call(self, use_case: str, name: str, user_text: str, image: bytes, mime: str, calls: CallLog) -> str:
        system, version = self._prompts.get(name)
        shown = [{"role": "system", "content": system}, {"role": "user", "content": user_text + "\n[ảnh: không đưa vào nhật ký]"}]
        started = time.perf_counter()
        try:
            res = await self._vision.describe(use_case=use_case, system=system, user_text=user_text, image_bytes=image, mime=mime)
        except asyncio.CancelledError:  # the caller's timeout: the call is still part of the trace (IMP-48)
            self._record(calls, use_case, version, None, started, ok=False, error="timeout", messages=shown)
            raise
        except Exception as exc:
            self._record(calls, use_case, version, None, started, ok=False, error=type(exc).__name__, messages=shown)
            raise
        self._record(calls, use_case, version, res, started, ok=True, messages=shown)
        return res.text

    async def _structured(self, use_case: str, version: str, messages: list[ChatMessage], model: type[T], calls: CallLog,
                          parts: list[str] | None = None) -> T:
        msgs = list(messages)
        problem = ""
        for _attempt in (1, 2):
            shown = [{"role": m.role, "content": m.content} for m in msgs]
            started = time.perf_counter()
            try:
                res = await self._llm.complete(use_case=use_case, messages=msgs, response_model=model)
            except ModelError as exc:
                self._record(calls, use_case, version, None, started, ok=False, error=type(exc).__name__, messages=shown, parts=parts)
                raise
            try:
                parsed = model.model_validate_json(_json_text(res.text))
            except ValidationError as exc:
                problem = validation_summary(exc.errors())[:300]
                self._record(calls, use_case, version, res, started, ok=False, error=f"invalid_output: {problem}", messages=shown, parts=parts)
                msgs = [*msgs, ChatMessage("assistant", res.text), ChatMessage("user", f"{RETRY_HINT} Lỗi: {problem}")]
                continue
            self._record(calls, use_case, version, res, started, ok=True, messages=shown, parts=parts)
            return parsed
        raise OutputInvalid(f"{use_case}: output does not match the schema after one retry ({problem})")

    # ------------------------------------------------------------------ capabilities
    async def describe_image(self, image: bytes, mime: str, calls: CallLog) -> str:
        return await self._vision_call("sami.understand_image", "understand_image", "Hãy mô tả ảnh này.", image, mime, calls)

    async def understand(self, messages: list[ChatMessage], intents: str, sections: list[str], model: type[T], calls: CallLog,
                         registry: str | None = None) -> T:
        """Core prompt (step 1, same for every intent) + one step-2 section per enabled intent with data to extract (IMP-47);
        ``registry`` (the intent registry's version) is recorded with the prompt files (IMP-48)."""
        loaded = [self._prompts.get(name) for name in sections]
        system, version = self._prompts.get("understand", intents_with_descriptions=intents,
                                            intent_sections="\n\n".join(text for text, _ in loaded))
        return await self._structured("sami.understand", version, [ChatMessage("system", system), *messages], model, calls,
                                      parts=[version, *(v for _, v in loaded), *([registry] if registry else [])])

    async def summarize(self, conversation: str, purpose: str, calls: CallLog) -> str:
        system, version = self._prompts.get("summarize", purpose=PURPOSE_TEXT.get(purpose, ""))
        msgs = [ChatMessage("system", system), ChatMessage("user", conversation)]
        shown = [{"role": m.role, "content": m.content} for m in msgs]
        started = time.perf_counter()
        try:
            res = await self._llm.complete(use_case="sami.summarize", messages=msgs, response_model=None)
        except ModelError as exc:
            self._record(calls, "sami.summarize", version, None, started, ok=False, error=type(exc).__name__, messages=shown)
            raise
        ok = bool(res.text.strip())
        self._record(calls, "sami.summarize", version, res, started, ok=ok, error=None if ok else "empty_output", messages=shown)
        if not ok:
            raise OutputInvalid("sami.summarize: empty summary")
        return res.text.strip()

    async def answer(self, rendered: str, model: type[T], calls: CallLog, language: Language | None = None) -> T:
        """Answers the question in ``rendered`` from its <passage> tags only (TDD S07); the service checks the cited ids."""
        system, version = self._prompts.get("answer", reply_language=REPLY_LANGUAGE[language])
        return await self._structured("sami.answer", version, [ChatMessage("system", system), ChatMessage("user", rendered)], model, calls)

    async def shield(self, user_text: str, documents: list[str]) -> ShieldResult:
        """Prompt Shields on the customer's text and the image description; fails open (the verifier still protects)."""
        docs = [d for d in documents if d.strip()]
        if self._shield is None or not (user_text.strip() or docs):
            return ShieldResult()
        try:
            return await self._shield.analyze(user_text, docs)
        except Exception:  # noqa: BLE001
            log.warning("shield_failed")
            return ShieldResult()
