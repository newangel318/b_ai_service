"""Sami ai-service: stateless AI capabilities for chat-service (group H, Đặc tả /understand)."""

__version__ = "0.2.0"
