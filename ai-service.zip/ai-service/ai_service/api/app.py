"""FastAPI app of ai-service (group H). Internal only: no WSO2 route; only chat-service calls it (D-16), with X-Internal-Key."""

from __future__ import annotations

import hmac
import time
from collections.abc import Awaitable
from dataclasses import dataclass
from typing import Any

import structlog
from fastapi import APIRouter, Depends, FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from ai_service import __version__
from ai_service.config import Settings
from ai_service.contract import (
    AnswerRequest,
    AnswerResponse,
    ErrorBody,
    ErrorDetail,
    SummarizeRequest,
    SummarizeResponse,
    UnderstandRequest,
    UnderstandResponse,
)
from ai_service.errors import AiError, Unauthorized, Unavailable, validation_summary
from ai_service.logging_setup import get_logger
from ai_service.understand.answer import AnswerService
from ai_service.understand.service import UnderstandService
from ai_service.understand.summarize import SummarizeService

PREFIX = "/internal/ai/v1"
ERRORS: dict[int | str, dict[str, Any]] = {code: {"model": ErrorBody} for code in (400, 401, 413, 422, 429, 503, 504)}
log = get_logger("api")


@dataclass(frozen=True)
class Services:
    understand: UnderstandService
    summarize: SummarizeService
    answer: AnswerService


async def _call[R: (UnderstandResponse, SummarizeResponse, AnswerResponse)](endpoint: str, request_id: str, turn_id: str | None,
                                                                          work: Awaitable[R]) -> R:
    """Runs one request with its ids bound to every log line, and writes one ``request_done`` line: ``request_id`` alone
    finds the prompts a request used (IMP-48)."""
    started = time.perf_counter()
    ids = {"request_id": request_id, "turn_id": turn_id, "endpoint": endpoint}
    with structlog.contextvars.bound_contextvars(**ids):
        try:
            res = await work
        except AiError as exc:
            exc.request_id, exc.traced = request_id, True
            log.warning("request_done", **ids, status=exc.status, error=exc.code, latency_ms=int((time.perf_counter() - started) * 1000))
            raise
        except Exception as exc:  # a bug must still answer the contract's error body, never a bare 500 (spec 5)
            log.exception("unexpected_error", **ids)
            err = Unavailable("internal error")
            err.request_id, err.traced = request_id, True
            log.warning("request_done", **ids, status=err.status, error=err.code, latency_ms=int((time.perf_counter() - started) * 1000))
            raise err from exc
        extra: dict[str, object] = {"intent": res.intent, "image_status": res.image.status if res.image else None} if isinstance(res, UnderstandResponse) else {}
        log.info("request_done", **ids, status=200, prompt_version=res.meta.prompt_version, prompts=res.meta.prompts,
                 latency_ms=res.meta.latency_ms.get("total"), **extra)
        return res


def create_app(services: Services | None = None, settings: Settings | None = None) -> FastAPI:
    cfg = settings or Settings()
    app = FastAPI(title="Sami ai-service", version=__version__, openapi_url=f"{PREFIX}/openapi.json", docs_url=None, redoc_url=None)

    async def require_internal_key(x_internal_key: str | None = Header(default=None)) -> None:
        """An empty AI_INTERNAL_KEY (fake mode only) turns the check off (IMP-46 (6))."""
        if cfg.ai_internal_key and not hmac.compare_digest((x_internal_key or "").encode(), cfg.ai_internal_key.encode()):
            raise Unauthorized("missing or wrong X-Internal-Key")

    def svc() -> Services:
        if services is None:
            raise Unavailable("ai-service is not configured")
        return services

    def debug_on(header: str | None) -> bool:
        return cfg.ai_debug_trace and header == "1"

    def rejected(request: Request, status: int, detail: ErrorDetail) -> JSONResponse:
        """A request answered before it reached a service still gets its request_done line (IMP-48 (3))."""
        log.warning("request_done", request_id=detail.request_id, turn_id=None, endpoint=request.url.path.rsplit("/", 1)[-1], status=status,
                    error=detail.code)
        return JSONResponse(status_code=status, content=ErrorBody(error=detail).model_dump(mode="json"))

    @app.exception_handler(RequestValidationError)
    async def bad_request(request: Request, exc: RequestValidationError) -> JSONResponse:
        """A request off the schema is a chat-service programming error: 400 AI_BAD_REQUEST, not 422 (spec 5)."""
        detail = ErrorDetail(code="AI_BAD_REQUEST", message=validation_summary(exc.errors()), retryable=False, request_id=request.headers.get("x-request-id"))
        return rejected(request, 400, detail)

    @app.exception_handler(AiError)
    async def ai_error(request: Request, exc: AiError) -> JSONResponse:
        body = exc.body(exc.request_id or request.headers.get("x-request-id"))
        if not exc.traced:
            return rejected(request, exc.status, body.error)
        return JSONResponse(status_code=exc.status, content=body.model_dump(mode="json"))

    @app.exception_handler(Exception)
    async def unexpected(request: Request, exc: Exception) -> JSONResponse:
        log.exception("unexpected_error")
        return rejected(request, 503, Unavailable("internal error").body(request.headers.get("x-request-id")).error)

    @app.get("/healthz", include_in_schema=False)
    async def healthz() -> dict[str, str]:
        return {"status": "ok", "llm_provider": cfg.llm_provider}

    router = APIRouter(prefix=PREFIX, dependencies=[Depends(require_internal_key)])

    @router.post("/understand", response_model=UnderstandResponse, responses=ERRORS)
    async def understand(body: UnderstandRequest, x_request_id: str | None = Header(default=None), traceparent: str | None = Header(default=None),
                         x_debug_trace: str | None = Header(default=None)) -> UnderstandResponse:
        return await _call("understand", body.request_id, body.turn_id, svc().understand.understand(body, debug=debug_on(x_debug_trace)))

    @router.post("/summarize", response_model=SummarizeResponse, responses=ERRORS)
    async def summarize(body: SummarizeRequest, x_request_id: str | None = Header(default=None), traceparent: str | None = Header(default=None),
                        x_debug_trace: str | None = Header(default=None)) -> SummarizeResponse:
        return await _call("summarize", body.request_id, None, svc().summarize.summarize(body, debug=debug_on(x_debug_trace)))

    @router.post("/answer", response_model=AnswerResponse, responses=ERRORS)
    async def answer(body: AnswerRequest, x_request_id: str | None = Header(default=None), traceparent: str | None = Header(default=None),
                     x_debug_trace: str | None = Header(default=None)) -> AnswerResponse:
        """Answers ``question`` from the given passages only (TDD S07); ``grounded=false`` when they do not answer it."""
        return await _call("answer", body.request_id, body.turn_id, svc().answer.answer(body, debug=debug_on(x_debug_trace)))

    app.include_router(router)
    return app
