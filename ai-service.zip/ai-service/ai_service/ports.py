"""Model-client ports. Only ``ai_service/capabilities/`` may call them; adapters translate SDK errors into ``ModelError``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from pydantic import BaseModel


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class ModelResult:
    text: str
    usage: Usage = field(default_factory=Usage)
    latency_ms: int = 0
    deployment: str = ""


@dataclass
class ChatMessage:
    role: str  # "system" | "user" | "assistant"
    content: str


@dataclass(frozen=True)
class ShieldResult:
    text_attack: bool = False
    document_attack: bool = False


class ModelError(Exception):
    """A model call failed (adapter-level)."""


class ModelRateLimited(ModelError):
    """429 from the model endpoint or AI Gateway."""


class ModelUnavailable(ModelError):
    """Connection error, 5xx or another refusal."""


class ModelTimeout(ModelError):
    """The SDK gave up waiting."""


class VisionClient(Protocol):
    async def describe(self, *, use_case: str, system: str, user_text: str, image_bytes: bytes, mime: str) -> ModelResult: ...


class LlmClient(Protocol):
    async def complete(self, *, use_case: str, messages: list[ChatMessage], response_model: type[BaseModel] | None = None) -> ModelResult: ...


class ShieldClient(Protocol):
    async def analyze(self, user_text: str, documents: list[str]) -> ShieldResult: ...
