"""Azure OpenAI and Content Safety adapters. Calls are stateless; chat-service owns the conversation (U1).
SDK errors become port errors here, so capabilities and the API never see the SDK."""

from __future__ import annotations

import base64
import json
import time
from typing import Any

import httpx
import httpx2  # the HTTP library of openai>=3: an injected OpenAI client must be one of its clients
from openai import APIError, APITimeoutError, AsyncAzureOpenAI, BadRequestError, RateLimitError
from pydantic import BaseModel

from ai_service.config import Settings
from ai_service.ports import ChatMessage, ModelError, ModelRateLimited, ModelResult, ModelTimeout, ModelUnavailable, ShieldResult, Usage


def _client(settings: Settings, http_client: httpx2.AsyncClient | None, max_retries: int) -> AsyncAzureOpenAI:
    return AsyncAzureOpenAI(azure_endpoint=settings.azure_openai_endpoint, api_key=settings.azure_openai_api_key,
                            api_version=settings.azure_openai_api_version, timeout=30.0, max_retries=max_retries, http_client=http_client)


def _usage(resp: Any) -> Usage:
    u = getattr(resp, "usage", None)
    return Usage(getattr(u, "prompt_tokens", 0) or 0, getattr(u, "completion_tokens", 0) or 0)


def _translate(exc: APIError) -> ModelError:
    if isinstance(exc, RateLimitError):
        return ModelRateLimited(str(exc))
    if isinstance(exc, APITimeoutError):
        return ModelTimeout(str(exc))
    return ModelUnavailable(str(exc))


class AzureVisionClient:
    def __init__(self, settings: Settings, *, http_client: httpx2.AsyncClient | None = None, max_retries: int = 1) -> None:
        self._c = _client(settings, http_client, max_retries)
        self._deployment = settings.azure_openai_deployment_vision

    async def describe(self, *, use_case: str, system: str, user_text: str, image_bytes: bytes, mime: str) -> ModelResult:
        data_url = f"data:{mime};base64,{base64.b64encode(image_bytes).decode()}"
        started = time.perf_counter()
        try:
            resp = await self._c.chat.completions.create(
                model=self._deployment, temperature=0,
                messages=[{"role": "system", "content": system},
                          {"role": "user", "content": [{"type": "text", "text": user_text},
                                                       {"type": "image_url", "image_url": {"url": data_url, "detail": "high"}}]}])
        except APIError as exc:
            raise _translate(exc) from exc
        return ModelResult(text=resp.choices[0].message.content or "", usage=_usage(resp),
                           latency_ms=int((time.perf_counter() - started) * 1000), deployment=self._deployment)


class AzureLlmClient:
    def __init__(self, settings: Settings, *, http_client: httpx2.AsyncClient | None = None, max_retries: int = 1) -> None:
        self._c = _client(settings, http_client, max_retries)
        text = settings.azure_openai_deployment_text
        self._deployments = {"sami.understand": text, "sami.summarize": settings.azure_openai_deployment_summary or text,
                             "sami.answer": text}

    async def complete(self, *, use_case: str, messages: list[ChatMessage], response_model: type[BaseModel] | None = None) -> ModelResult:
        deployment = self._deployments.get(use_case) or self._deployments["sami.understand"]
        payload = [{"role": m.role, "content": m.content} for m in messages]
        kwargs: dict[str, Any] = {"model": deployment, "messages": payload, "temperature": 0}
        if response_model is not None:
            kwargs["response_format"] = {"type": "json_schema", "json_schema": {"name": response_model.__name__,
                                                                                "schema": response_model.model_json_schema(), "strict": False}}
        started = time.perf_counter()
        try:
            try:
                resp = await self._c.chat.completions.create(**kwargs)
            except BadRequestError:
                if response_model is None:
                    raise
                # deployment without json_schema support: JSON mode; capabilities validate with Pydantic
                kwargs["response_format"] = {"type": "json_object"}
                kwargs["messages"] = [*payload, {"role": "user", "content": "Trả về JSON theo schema: " + json.dumps(response_model.model_json_schema())}]
                resp = await self._c.chat.completions.create(**kwargs)
        except APIError as exc:
            raise _translate(exc) from exc
        return ModelResult(text=resp.choices[0].message.content or "", usage=_usage(resp),
                           latency_ms=int((time.perf_counter() - started) * 1000), deployment=deployment)


class AzureShieldClient:
    """Azure AI Content Safety – Prompt Shields on the customer's text (userPrompt) and the image description (documents)."""

    def __init__(self, settings: Settings, *, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self._endpoint = settings.content_safety_endpoint.rstrip("/")
        self._key = settings.content_safety_key
        self._transport = transport

    async def analyze(self, user_text: str, documents: list[str]) -> ShieldResult:
        async with httpx.AsyncClient(timeout=3.0, transport=self._transport) as c:
            r = await c.post(f"{self._endpoint}/contentsafety/text:shieldPrompt", params={"api-version": "2024-09-01"},
                             headers={"Ocp-Apim-Subscription-Key": self._key}, json={"userPrompt": user_text, "documents": documents})
        r.raise_for_status()
        body = r.json()
        return ShieldResult(text_attack=bool(body.get("userPromptAnalysis", {}).get("attackDetected", False)),
                            document_attack=any(bool(d.get("attackDetected")) for d in body.get("documentsAnalysis", [])))
