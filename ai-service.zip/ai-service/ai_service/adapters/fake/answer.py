"""Fake /answer: takes the first passage (search order) sharing enough words with the question and returns its first sentences. Measures the
plumbing (citations, grounded or not), not answer quality."""

from __future__ import annotations

import re
from typing import Any

from ai_service.adapters.fake.intent import tag
from ai_service.adapters.fake.text import fold

STOP = frozenset("a ai cho co cua da de gi giup hay khi khong la lam ma minh mot nao nay nhe nhieu nhu o sao sami thi toi va ve voi xin".split())


def _words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]+", fold(text)) if w not in STOP and len(w) > 1}


def fake_answer(prompt: str, *, english: bool = False) -> dict[str, Any]:
    asked = _words(tag(prompt, "question") or "")
    passages = re.findall(r'<passage id="([^"]*)">\n(.*?)\n</passage>', prompt, re.DOTALL)
    # the first passage (search order) sharing enough words with the question
    best = next(((pid, body) for pid, body in passages if asked and len(asked & _words(body)) >= min(2, len(asked))), None)
    if best is None:
        return {"grounded": False, "answer": "", "used_passage_ids": []}
    text = best[1].split("\n", 1)[1] if "\n" in best[1] else best[1]  # drop the "title › heading" line
    sentences = re.split(r"(?<=[.!?])\s+", " ".join(text.split()))
    return {"grounded": True, "answer": ("According to Sami's documents: " if english else "") + " ".join(sentences[:2]), "used_passage_ids": [best[0]]}
