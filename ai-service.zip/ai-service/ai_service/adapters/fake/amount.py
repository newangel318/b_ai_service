"""Deterministic Vietnamese money-phrase parser. Returns whole VND or ``None`` (never guesses)."""

from __future__ import annotations

import re
import unicodedata

from ai_service.adapters.fake.text import fold

CURRENCY_TAIL = r"(?:\s*(?:đ|d|vnd|vnđ|dong|đồng))?"
FOREIGN = re.compile(r"(\$|usd|eur|€|£|\bjpy\b|yen|\bgbp\b|\b(?:bnd|sgd|aud|cad|nzd|hkd|twd|cny|rmb|krw|thb|myr|chf|inr)\b)", re.IGNORECASE)

# unit word -> multiplier (after folding diacritics)
UNITS: dict[str, int] = {
    "k": 1_000, "nghin": 1_000, "ngan": 1_000,
    "tr": 1_000_000, "trieu": 1_000_000, "cu": 1_000_000, "m": 1_000_000,
    "lit": 100_000, "xi": 100_000,
    "ty": 1_000_000_000, "toi": 1_000_000_000,
    # English: whole words only (the unit regex takes the whole letter run, so "mins" / "mill" are no unit)
    "thousand": 1_000, "mil": 1_000_000, "million": 1_000_000, "millions": 1_000_000,
    "bn": 1_000_000_000, "billion": 1_000_000_000, "billions": 1_000_000_000,
}
# English unit words: no "remainder" shorthand after them ("2 million 500" is never 2.5 million)
ENGLISH = {"thousand", "mil", "million", "millions", "bn", "billion", "billions"}
# units that also stand without a number: "nửa củ" = 500,000 ; "củ rưỡi" = 1,500,000
SPOKEN = {"cu", "toi", "trieu", "ty", "lit", "xi", "nghin", "ngan"}
# multiplier of the "remainder" digit(s): "1tr2" -> 1.2tr ; "5 lít" etc. are plain
SMALLER: dict[int, int] = {1_000_000: 100_000, 1_000: 100, 1_000_000_000: 100_000_000}


def _num(s: str) -> float | None:
    s = s.strip()
    if not s:
        return None
    if re.fullmatch(r"\d+", s):
        return float(int(s))
    if re.fullmatch(r"\d+[.,]\d+", s):  # decimal when used with a unit: 1,2 triệu / 1.2tr
        return float(s.replace(",", "."))
    return None


def _plain_digits(s: str) -> int | None:
    """12.500.000 / 12,500,000 / 12500000 (thousand separators only)."""
    if re.fullmatch(r"\d{1,3}([.,]\d{3})+", s):
        return int(re.sub(r"[.,]", "", s))
    if re.fullmatch(r"\d+", s):
        return int(s)
    return None


def _toi_is_spelled(text: str, *units: str | None) -> bool:
    """"toi" is a unit only when written "tỏi": folded, it is also "tôi", "tới", "tối" ("5 tối nay" is not 5 tỷ)."""
    return "toi" not in units or "tỏi" in unicodedata.normalize("NFC", text).lower()


def parse_amount(text: str) -> int | None:
    t = fold(text)
    if not t or FOREIGN.search(text):
        return None
    t = re.sub(r"\s+", " ", t).strip()
    # strip a trailing currency word ("500kđ", "2tr vnd"), unless the "d" ends a unit word ("thousand") or stripping it
    # would make an English unit word out of another word ("bnd" is no "bn" + đ, "mild" no "mil" + đ)
    last_word = re.search(r"[a-z]+$", t)
    if not (last_word and last_word.group() in UNITS):
        cur = re.search(r"\s*(vnd|vnđ|dong|d)$", t)
        if cur and not (cur.group(0) == "d" and (rest := re.search(r"[a-z]+$", t[: cur.start()])) and rest.group() in ENGLISH):
            t = t[: cur.start()].strip()

    # ---- plain number with thousand separators (no unit): 12.500.000 | 12,500,000 | 12500000
    plain = _plain_digits(t)
    if plain is not None:
        return plain if plain > 0 else None
    if re.fullmatch(r"\d+[.,]\d{1,2}", t) and not re.search(r"[a-z]", t):
        return None  # 12.500,50 style decimals / 12,5 without unit are not accepted

    # ---- spoken forms without a number: "nửa củ" (half a unit), "củ rưỡi" (one and a half)
    bare = re.fullmatch(r"nua ([a-z]+)|([a-z]+) ruoi", t)
    if bare:
        half, and_half = bare.groups()
        word = half or and_half
        if word not in SPOKEN or not _toi_is_spelled(text, word):
            return None
        return UNITS[word] // 2 if half else UNITS[word] * 3 // 2

    # ---- "<n> <unit> [<n2> [<unit2>]]" forms, also "rưỡi"
    m = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*([a-z]+)(?:\s*(\d+)\s*([a-z]+)?|\s+ruoi)?", t)
    if not m:
        return None
    head, unit, tail, tail_unit = m.groups()
    mult = UNITS.get(unit)
    if mult is None or not _toi_is_spelled(text, unit, tail_unit):
        return None
    value = _num(head)
    if value is None:
        return None
    # "1.100k" / "1,100k" = 1.100 nghìn: a "." or "," before a 3-digit group is a thousands separator (both are used in chat)
    if mult == 1_000 and re.fullmatch(r"\d{1,3}[.,]\d{3}", head) and tail is None and not t.endswith(" ruoi"):
        return int(re.sub(r"[.,]", "", head)) * 1_000
    # before 1-2 digits it is a decimal point ("1.5k" = 1,500); anything else with k/nghin is ambiguous -> reject
    if mult == 1_000 and not re.fullmatch(r"\d+(?:[.,]\d{1,2})?", head):
        return None
    # "1.500 triệu": a 3-digit group is a thousands separator in Vietnamese (1,500 triệu) but a decimal elsewhere -> reject
    if re.fullmatch(r"\d+[.,]\d{3}", head):
        return None
    total = value * mult
    if t.endswith(" ruoi"):
        total += mult // 2
    elif tail is not None:
        if unit in ENGLISH and not tail_unit:
            return None
        if tail_unit:
            tmult = UNITS.get(tail_unit)
            if tmult is None or tmult >= mult:
                return None
            total += int(tail) * tmult
        else:
            # "1tr2" -> 1.2tr ; "1 triệu 200" -> 1,200,000 ; "5 lít 5" -> 550000
            digits = len(tail)
            if digits == 1 and mult in SMALLER:
                total += int(tail) * SMALLER[mult]
            elif mult in (1_000_000, 1_000_000_000) and digits == 3 and mult == 1_000_000:
                total += int(tail) * 1_000
            elif mult == 100_000 and digits == 1:
                total += int(tail) * 10_000
            else:
                return None
    result = round(total)
    return result if result > 0 and float(result) == round(total, 6) else None
