"""Offline stand-in for the model's language call (tests and evals, not quality): Vietnamese letters or no word that shows
a language → look at the earlier turns → Vietnamese. Anything else with an English word is English."""

from __future__ import annotations

import re

from ai_service.contract.common import Language

VIETNAMESE_LETTERS = re.compile("[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]", re.IGNORECASE)
ENGLISH_WORDS = frozenset("transfer send money to my the is what how much fee rate please agent staff balance limit gold card account".split())


def _shows(text: str) -> Language | None:
    if VIETNAMESE_LETTERS.search(text):
        return "vi"
    return "en" if ENGLISH_WORDS.intersection(re.findall(r"[a-z]+", text.lower())) else None


def fake_language(user_text: str, earlier_user_texts: list[str]) -> Language:
    """``earlier_user_texts`` is oldest first; the newest one that shows a language decides."""
    for text in (user_text, *reversed(earlier_user_texts)):
        if (shown := _shows(text)) is not None:
            return shown
    return "vi"
