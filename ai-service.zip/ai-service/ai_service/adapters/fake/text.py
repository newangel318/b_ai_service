"""Text helpers: Vietnamese diacritics folding, whole-word matching, whitespace normalization."""

from __future__ import annotations

import re
import unicodedata


def fold(text: str) -> str:
    """Lowercase, strip diacritics (đ -> d), collapse whitespace."""
    t = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    t = "".join(c for c in t if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"\s+", " ", t).strip()


def strip_diacritics(text: str) -> str:
    """Remove Vietnamese diacritics keeping case (đ -> d, Đ -> D)."""
    t = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def squash_ws(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def contains_word(haystack_folded: str, needle_folded: str) -> bool:
    """Whole-word containment on already folded strings."""
    if not needle_folded:
        return False
    return re.search(rf"(?<![a-z0-9]){re.escape(needle_folded)}(?![a-z0-9])", haystack_folded) is not None


def upper_name(text: str) -> str:
    """For name comparison: remove diacritics, uppercase, collapse spaces."""
    return fold(text).upper()
