"""Bank names bundled for the fake extractor only (IMP-39): ai-service has no bank API client (U1)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from ai_service.adapters.fake.text import contains_word, fold

DATA = Path(__file__).resolve().with_name("banks.json")


@dataclass(frozen=True)
class Bank:
    bank_code: str
    name: str
    bank_legal_name: str
    napas_code: str


class BundledBanks:
    def __init__(self, banks: list[Bank], aliases: dict[str, list[str]]) -> None:
        self._banks = banks
        self._aliases = aliases  # read by the legacy extractor (_aliases_of)

    @classmethod
    def load(cls, path: Path = DATA) -> BundledBanks:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return cls([Bank(**b) for b in raw["banks"]], {k: list(v) for k, v in raw["aliases"].items()})

    def _names(self, b: Bank) -> set[str]:
        return {n for n in (fold(x) for x in [b.name, b.bank_legal_name, b.bank_code, *self._aliases.get(b.bank_code, [])]) if n}

    async def find_in_text(self, text: str) -> list[Bank]:
        """Banks named in ``text`` (longest name first); a name only inside another bank's longer match does not count."""
        t = fold(text)
        spans: list[tuple[int, int, Bank]] = []
        for b in self._banks:
            for n in self._names(b):
                if contains_word(t, n):
                    spans += [(m.start(), m.end(), b) for m in re.finditer(rf"(?<![a-z0-9]){re.escape(n)}(?![a-z0-9])", t)]
        hits: dict[str, tuple[int, Bank]] = {}
        for start, end, b in spans:
            inside_other = any(o is not b and s0 <= start and end <= e0 and (e0 - s0) > (end - start) for s0, e0, o in spans)
            if not inside_other and end - start > hits.get(b.bank_code, (0, b))[0]:
                hits[b.bank_code] = (end - start, b)
        return [b for _, b in sorted(hits.values(), key=lambda x: -x[0])]

    async def code_for_name(self, name: str | None) -> str | None:
        found = await self.find_in_text(name) if name else []
        return found[0].bank_code if found else None
