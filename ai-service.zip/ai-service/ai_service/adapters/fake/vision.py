"""Fake vision client: returns the generator's sidecar for an image found by the sha256 of its bytes (IMP-39)."""

from __future__ import annotations

import hashlib
from pathlib import Path

from ai_service.ports import ModelResult, Usage

NO_INFO = "TÓM TẮT: Ảnh không có thông tin chuyển tiền."
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp"}


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class FakeVisionClient:
    def __init__(self, sidecar_dirs: list[Path]) -> None:
        self._dirs = list(sidecar_dirs)
        self._seen: dict[Path, float] = {}
        self.index: dict[str, Path] = {}
        self._scan()

    def _scan(self) -> None:
        """Hashes the images not seen before (or changed since): tests and generators write images while the service runs.
        The first directory listing an image wins, as before."""
        for d in self._dirs:
            if not d.is_dir():
                continue
            for p in sorted(d.iterdir()):
                if p.suffix.lower() in IMAGE_SUFFIXES and self._seen.get(p) != (mtime := p.stat().st_mtime):
                    self._seen[p] = mtime
                    self.index.setdefault(_digest(p), p)

    async def describe(self, *, use_case: str, system: str, user_text: str, image_bytes: bytes, mime: str) -> ModelResult:
        digest = hashlib.sha256(image_bytes).hexdigest()
        if digest not in self.index:
            self._scan()
        image = self.index.get(digest)
        text = NO_INFO
        if image is not None:
            found = image.with_name(image.stem + ".desc.txt")
            if found.is_file():
                text = found.read_text(encoding="utf-8").strip()
        return ModelResult(text=text, usage=Usage(len(image_bytes) // 1000, len(text) // 4), deployment="fake-vision")
