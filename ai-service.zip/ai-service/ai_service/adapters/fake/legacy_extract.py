"""Offline heuristic stand-in for ``sami.transfer_extract``: produces the TransferExtraction schema with evidence.

It exists to exercise the whole pipeline without a model (tests, demos with generator sidecars) – not for quality.
It only reads what a real model would see in the prompt (``<customer_context>``, ``<task_state>``, ``<current_turn>``).
"""

from __future__ import annotations

import json
import re
from typing import Any

from ai_service.adapters.fake.amount import parse_amount
from ai_service.adapters.fake.banks import BundledBanks as BankDirectoryPort
from ai_service.adapters.fake.text import contains_word, fold

SELF_ACCOUNT_CUES = ("cua toi", "cua ban", "cua minh", "nguon", "tk cua", "ban dang dung", "tai khoan cua")
ACCOUNT_LABELS = ("stk", "so tai khoan", "so tk", "tai khoan nhan", "tai khoan", "account", "so tai khoan nhan")
BANK_LABELS = ("ngan hang", "bank", "nh ", "tai ngan hang")
NAME_LABELS = ("ten nguoi nhan", "chu tai khoan", "nguoi thu huong", "don vi thu huong", "ten tai khoan", "thu huong", "ten tk", "ten chu",
               "nguoi nhan", "account holder", "ho ten", "ten")
REF_LABELS = ("noi dung chuyen khoan", "noi dung chuyen tien", "thong tin chuyen khoan", "noi dung ck", "noi dung", "loi nhan", "ghi chu",
              "dien giai")
NOTE_SENTENCES = (r"ghi chinh xac la\s+(\S+)", r"giu nguyen noi dung chuyen khoan\s+(\S+)")
POLITE_TAIL = {"nha", "nhe", "nhé", "nhá", "ạ", "chị", "anh", "em", "giúp", "dùm"}
VIRTUAL_ACCOUNT = re.compile(r"\b[A-Z]{1,8}\d{6,17}\b")
AMOUNT_PRIORITY = ("con phai nop", "can thanh toan", "so tien phai tra", "tong thanh toan", "phai thanh toan", "tong tien", "thanh tien",
                   "so tien chuyen khoan")
AMOUNT_LABELS = ("so tien", "thanh toan", "amount", "tien chuyen")
CORRECTION_MARKERS = ("dung la", "sua", "nham", "khong phai", "doi thanh", "a thoi", "chu khong", "thanh", "phai la")
NEW_RECIPIENT_MARKERS = ("nguoi khac", "cho nguoi khac", "chuyen cho nguoi")
POLITE = {"nhé", "nhá", "giúp", "ạ", "đi", "với", "cho", "tôi", "mình", "nha", "nhe"}
STOP_AFTER_AMOUNT = {"ben", "qua", "sang", "vao", "toi", "den", "stk", "so"}


def _tag(text: str, name: str) -> str | None:
    m = re.search(rf"<{name}(?:\s[^>]*)?>(.*?)</{name}>", text, re.DOTALL)
    return m.group(1).strip() if m else None


def _tokens(text: str) -> list[tuple[int, int, str]]:
    return [(m.start(), m.end(), fold(m.group()).strip(".,;:!?()[]\"'")) for m in re.finditer(r"\S+", text)]


def find_span(text: str, phrase: str) -> str | None:
    """Verbatim substring of ``text`` matching ``phrase`` ignoring case/diacritics (whole words)."""
    ptoks = [t for t in fold(phrase).split() if t]
    toks = _tokens(text)
    for i in range(len(toks) - len(ptoks) + 1):
        if all(toks[i + j][2] == ptoks[j] for j in range(len(ptoks))):
            return text[toks[i][0] : toks[i + len(ptoks) - 1][1]].strip(".,;:!?()[]\"'")
    return None


STRIP = ".,;:!?()[]\"'"


def account_runs(text: str, labelled: bool = False) -> list[tuple[str, str]]:
    """(digits, verbatim phrase) of account-number-like digit groups. Short runs (<8) need a label unless ``labelled``."""
    toks = list(re.finditer(r"\S+", text))
    out: list[tuple[str, str]] = []
    i = 0
    while i < len(toks):
        t = toks[i].group().strip(STRIP)
        if re.fullmatch(r"\d[\d.\-]*", t) and not re.fullmatch(r"\d{1,3}([.,]\d{3})+", t):
            j, digits = i, re.sub(r"[.\-]", "", t)
            if len(digits) <= 5:
                while j + 1 < len(toks):
                    nt = toks[j + 1].group().strip(STRIP)
                    if re.fullmatch(r"\d{2,5}", nt) and len(digits) + len(nt) <= 19:
                        digits += nt
                        j += 1
                    else:
                        break
            if 6 <= len(digits) <= 19:
                prev = " ".join(fold(toks[k].group()) for k in range(max(0, i - 3), i))
                if labelled or len(digits) >= 8 or any(k in prev for k in ("stk", "tk", "tai khoan", "so ")):
                    out.append((digits, text[toks[i].start() : toks[j].end()].strip(STRIP)))
            i = j + 1
        else:
            i += 1
    return out


def _amount_spans(text: str) -> list[tuple[str, int]]:
    """All amount phrases in order: (verbatim phrase, value). Greedy longest window first."""
    toks = _tokens(text)
    out: list[tuple[str, int]] = []
    i = 0
    while i < len(toks):
        raw = re.sub(r"[^\d.,a-z]", "", toks[i][2])
        if not raw or not raw[0].isdigit() or (len(re.sub(r"\D", "", raw)) >= 8 and not re.search(r"[.,]", raw) and not re.search(r"[a-z]", raw)):
            i += 1
            continue
        hit = None
        for n in range(min(4, len(toks) - i), 0, -1):
            phrase = text[toks[i][0] : toks[i + n - 1][1]].strip(".,;:!?()[]\"'")
            val = parse_amount(phrase)
            if val and phrase.isdigit() and val < 1000:
                val = None  # a bare small number ("cuối là 89") is not an amount
            if val:
                hit = (phrase, val, n)
                break
        if hit:
            out.append((hit[0], hit[1]))
            i += hit[2]
        else:
            i += 1
    return out


def after_label(line: str, labels: tuple[str, ...]) -> str | None:
    """The value after ``<label> [(…)]:`` – the colon that belongs to one of ``labels`` (not an earlier "Lưu ý:")."""
    for m in re.finditer(":", line):
        head = re.sub(r"\([^)]*\)\s*$", "", fold(line[: m.start()])).strip()
        if any(head == lbl or head.endswith(" " + lbl) for lbl in labels):
            value = re.sub(r"(\s*\([^)]*\))+\s*$", "", line[m.end() :]).strip()
            return value or None
    return None


def _cand(value: Any, evidence: str, source: str, ref: str | None = None) -> dict[str, Any]:
    d = {"value": value, "evidence": evidence, "source": source}
    if ref:
        d["context_ref"] = ref
    return d


CANCEL_PHRASES = (" thoi khong chuyen", " khong chuyen nua", " huy di", " huy giup", " huy giao dich", " huy yeu cau", " dung lai",
                  " bo qua di", " cancel ")


async def fake_extract(prompt: str, banks: BankDirectoryPort) -> dict[str, Any]:
    ctx = json.loads(_tag(prompt, "customer_context") or "{}")
    task_raw = _tag(prompt, "task_state") or "none"
    task = None if task_raw.strip() == "none" else json.loads(task_raw)
    current = _tag(prompt, "current_turn") or ""
    text = _tag(current, "user_text") or ""
    images = re.findall(r'<image_description id="([^"]+)">\n?(.*?)\n?</image_description>', current, re.DOTALL)
    out: dict[str, Any] = {"relation": "new", "change_type": None, "bank": [], "account_no": [], "amount": [], "reference": [],
                           "recipient_name_on_image": [], "recipient_ref": [], "source_account": []}
    ftext = fold(text)
    if any(p in f" {ftext} " for p in CANCEL_PHRASES):  # "thôi không chuyển nữa", "hủy đi": a request to drop the transfer
        out["change_type"] = "cancel"
        return out

    # ------------------------------------------------------------------ text
    for digits, phrase in account_runs(text):
        out["account_no"].append(_cand(digits, phrase, "text"))
    amounts = _amount_spans(text)
    account_digit_runs = {d for d, _ in account_runs(text)}
    amounts = [(p, v) for p, v in amounts if re.sub(r"\D", "", p) not in account_digit_runs]
    if amounts:
        phrase, value = amounts[-1]  # the last mention is the final one ("500k ... à thôi 300k")
        out["amount"].append(_cand(value, phrase, "text"))
        tail = text[text.rfind(phrase) + len(phrase) :]
        words = [w for w in re.findall(r"[^\s,.;!?]+", tail)]
        keep: list[str] = []
        for w in words:
            fw = fold(w)
            if fw in STOP_AFTER_AMOUNT:
                break
            if w.lower() in POLITE or fw.isdigit():
                continue
            keep.append(w)
        if keep:
            ref_phrase = " ".join(keep)
            span = find_span(text, ref_phrase)
            if span:
                out["reference"].append(_cand(span, span, "text"))

    found_banks = await banks.find_in_text(text)
    for b in found_banks:
        names = [b.name, b.bank_legal_name, b.bank_code]
        span = next((find_span(text, n) for n in names if n and find_span(text, n)), None)
        if span is None:
            span = next((s for s in (_alias_span(text, a) for a in _aliases_of(banks, b.bank_code)) if s), None)
        if span:
            out["bank"].append(_cand(b.name, span, "text"))

    if "luong" in ftext:
        sal = next((a for a in ctx.get("source_accounts", []) if a.get("accountType") == "SALARY"), None)
        span = find_span(text, "tài khoản lương") or find_span(text, "tk lương")
        if sal and span:
            out["source_account"].append(_cand(sal["accountNo"], span, "context", sal["accountNo"]))

    # ------------------------------------------------------------------ images
    for _image_id, desc in images:
        lines = [ln.strip() for ln in desc.splitlines() if ln.strip() and not ln.strip().startswith("[QR")]
        chat_amounts: list[tuple[str, int]] = []
        labelled: dict[str, list[tuple[str, int]]] = {"priority": [], "label": [], "other": []}
        for ln in lines:
            fl = fold(ln)
            if ln.startswith("TÓM TẮT"):
                continue
            listed = re.match(r"^(?:.*:\s*)?(\d{8,19})\s+-\s+\S", ln)  # "19135511792014 - Techcombank - CN Đông Đô"
            if any(k in fl for k in ACCOUNT_LABELS) and not any(c in fl for c in SELF_ACCOUNT_CUES):
                virtual = VIRTUAL_ACCOUNT.findall(ln)
                runs = account_runs(ln, labelled=True)
                if virtual:
                    out["account_no"].append(_cand(virtual[0], ln, "image"))
                elif runs and not any(k in fl for k in AMOUNT_PRIORITY):
                    out["account_no"].append(_cand(runs[0][0], ln, "image"))
            elif listed and await banks.find_in_text(ln):
                out["account_no"].append(_cand(listed.group(1), ln, "image"))
            bank_label = any(contains_word(fl, k.strip()) for k in BANK_LABELS)
            if (bank_label or any(k in fl for k in ACCOUNT_LABELS) or listed) and not any(c in fl for c in SELF_ACCOUNT_CUES):
                for b in await banks.find_in_text(ln):
                    out["bank"].append(_cand(b.name, ln, "image"))
            name = after_label(ln, NAME_LABELS)
            if name and UNREADABLE_MARK not in name:
                out["recipient_name_on_image"].append(_cand(name.rstrip("."), ln, "image"))
            note = after_label(ln, REF_LABELS)
            if note is None:
                hit = next((m for pat in NOTE_SENTENCES if (m := re.search(pat, fl))), None)
                if hit:
                    note = find_span(ln, hit.group(1))
            if note and UNREADABLE_MARK not in note:
                words = note.split()
                while len(words) > 1 and words[-1].lower().strip("!.,") in POLITE_TAIL:
                    words.pop()
                out["reference"].append(_cand(" ".join(words), ln, "image"))
            spans = [(p, v) for p, v in _amount_spans(ln) if len(re.sub(r"\D", "", p)) < 12 or re.search(r"[a-z]", fold(p))]
            digits_in_account_line = any(k in fl for k in ACCOUNT_LABELS)
            for _p, v in spans:
                if digits_in_account_line and not any(k in fl for k in AMOUNT_PRIORITY + AMOUNT_LABELS):
                    continue
                if any(k in fl for k in AMOUNT_PRIORITY):
                    labelled["priority"].append((ln, v))
                elif any(k in fl for k in AMOUNT_LABELS):
                    labelled["label"].append((ln, v))
                elif re.match(r"^\(?(trai|phai|left|right|ban|toi)\)?", fl) or "tin nhan" in fl or fl.startswith(("-", ">")):
                    chat_amounts.append((ln, v))
                else:
                    labelled["other"].append((ln, v))
        pick: list[tuple[str, int]]
        if labelled["priority"]:
            pick = labelled["priority"][-1:]
        elif chat_amounts:
            pick = chat_amounts[-1:]
        elif labelled["label"]:
            pick = labelled["label"] if len({v for _, v in labelled["label"]}) > 1 else labelled["label"][:1]
        else:
            pick = labelled["other"] if len({v for _, v in labelled["other"]}) > 1 else labelled["other"][:1]
        for ln, v in pick:
            out["amount"].append(_cand(v, ln, "image"))

    # ------------------------------------------------------------------ relation / change type
    if task:
        new_recipient = any(m in ftext for m in NEW_RECIPIENT_MARKERS)
        t_acct = str(task.get("account_no") or "")
        img_accounts = {c["value"] for c in out["account_no"] if c["source"] == "image"}
        if img_accounts and t_acct and not (img_accounts <= {t_acct}):
            new_recipient = True
        correction = any(m in ftext for m in CORRECTION_MARKERS) or any(
            m in ftext for m in ("xem lai anh", "doc lai", "cuoi la", "sai roi"))
        if correction:
            new_recipient = new_recipient and any(m in ftext for m in NEW_RECIPIENT_MARKERS)
        out["relation"] = "new" if new_recipient else "continue"
        out["change_type"] = "new_recipient" if new_recipient else ("correction" if correction else "fill")
    return out


UNREADABLE_MARK = "[không đọc rõ]"


def _aliases_of(banks: BankDirectoryPort, bank_code: str) -> list[str]:
    aliases = getattr(banks, "_aliases", {})
    return list(aliases.get(bank_code, []))


def _alias_span(text: str, alias: str) -> str | None:
    return find_span(text, alias)
