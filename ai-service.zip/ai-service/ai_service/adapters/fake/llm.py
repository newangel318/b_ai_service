"""Deterministic offline stand-in for the text deployments (offline tests and evals, not quality).

It reads only what a real model sees (the tags of ``ai_service/understand/render.py``) and runs the legacy fake extractor
of ai-assistant-service through a small adapter, so offline evals behave as before the split (IMP-46 (9)).
"""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel

from ai_service.adapters.fake.answer import fake_answer
from ai_service.adapters.fake.banks import BundledBanks
from ai_service.adapters.fake.intent import fake_turn, no_new_info, tag, tags
from ai_service.adapters.fake.language import fake_language
from ai_service.adapters.fake.legacy_extract import fake_extract
from ai_service.adapters.fake.text import fold
from ai_service.ports import ChatMessage, ModelResult, Usage

FIELD_KEYS = ("bank", "account_no", "amount", "reference", "recipient_name_on_image")
# the customer disputes a value read from the image (folded): the real model answers `objection`
OBJECTION_CUES = (" xem lai anh", " doc lai anh", " nhin lai anh", " doc sai", " doc nham", " sai roi")


def _legacy_context(ctx: dict[str, Any]) -> dict[str, Any]:
    """Adapt the remaining source-account references to the legacy extractor's prompt shape."""
    accounts = [{"accountNo": a["account_ref"], "accountType": "SALARY" if "luong" in fold(a["alias"]) else "PAYMENT"}
                for a in ctx.get("source_accounts", [])]
    return {"saved_beneficiaries": [], "recent_beneficiaries": [], "source_accounts": accounts}


def _from_legacy(old: dict[str, Any], has_task: bool) -> dict[str, Any]:
    if old["change_type"] == "cancel":
        return {"change_type": "cancel"}
    out: dict[str, Any] = {"change_type": old["change_type"] or "fill", "fields": {}}
    if has_task:
        out["relation"] = old["relation"]
    for key in FIELD_KEYS:
        cands = [{"value": c["value"], "evidence": c["evidence"], "from": c["source"]} for c in old[key] if c["source"] in ("text", "image")]
        if cands:
            out["fields"][key] = cands
    if old["source_account"]:
        c = old["source_account"][0]
        out["source_account"] = {"account_ref": c["value"], "evidence": c["evidence"]}
    return out


async def fake_understand(prompt: str, banks: BundledBanks, earlier_user_texts: list[str] | None = None) -> dict[str, Any]:
    ctx = json.loads(tag(prompt, "customer_context") or "{}")
    task_raw = (tag(prompt, "task_state") or "none").strip()
    task = None if task_raw == "none" else json.loads(task_raw)
    current = tag(prompt, "current_turn") or ""
    user_text = tag(current, "user_text") or ""
    turn = fake_turn(user_text, "\n".join(tags(current, "image_description")), str(task.get("task_type") or "transfer.domestic") if task else None)
    out: dict[str, Any] = {**turn, "change_type": "none", "fields": {}, "language": fake_language(user_text, earlier_user_texts or [])}
    if turn["intent"] != "transfer.domestic" or no_new_info(user_text):  # "ok": nothing to extract
        return out
    legacy_task = {"account_no": ((task.get("fields") or {}).get("account_no") or {}).get("value")} if task else None
    legacy_prompt = "\n".join([
        f"<customer_context>\n{json.dumps(_legacy_context(ctx), ensure_ascii=False)}\n</customer_context>",
        f"<task_state>\n{json.dumps(legacy_task, ensure_ascii=False)}\n</task_state>" if legacy_task else "<task_state>none</task_state>",
        f"<current_turn>\n{current}\n</current_turn>",
    ])
    result = {**out, **_from_legacy(await fake_extract(legacy_prompt, banks), task is not None)}
    if task is not None and any(cue in f" {fold(user_text)} " for cue in OBJECTION_CUES):  # "xem lại ảnh đi, số cuối là 89"
        field = "amount" if " tien" in f" {fold(user_text)}" and "tai khoan" not in fold(user_text) else "account_no"
        result["objection"] = {"field": field, "claim": user_text.strip(), "evidence": user_text.strip()}
    return result


class FakeLlmClient:
    def __init__(self, banks: BundledBanks) -> None:
        self._banks = banks

    async def complete(self, *, use_case: str, messages: list[ChatMessage], response_model: type[BaseModel] | None = None) -> ModelResult:
        last = messages[-1].content if messages else ""
        usage = Usage(sum(len(m.content) for m in messages) // 4, 30)
        if use_case == "sami.understand":
            return ModelResult(text=json.dumps(await fake_understand(last, self._banks, [t for m in messages[:-1] if m.role == "user" and (t := tag(m.content, "user_text"))]), ensure_ascii=False), usage=usage, deployment="fake-text")
        if use_case == "sami.answer":
            return ModelResult(text=json.dumps(fake_answer(last, english="Write the answer in English" in messages[0].content), ensure_ascii=False), usage=usage, deployment="fake-text")
        if use_case == "sami.summarize":
            body = " ".join(m.content for m in messages if m.role != "system")
            return ModelResult(text="Khách hàng trao đổi với Sami. " + body[-300:], usage=usage, deployment="fake-summary")
        raise ValueError(f"fake llm: unsupported use case {use_case}")
