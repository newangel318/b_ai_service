"""Legacy fake intent of ai-assistant-service (verbatim logic) plus the IMP-47 step-1 output (image relevance)."""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from ai_service.adapters.fake.language import fake_language


def fold(text: str) -> str:
    """Lowercase, strip diacritics (đ -> d). No whitespace collapse: the keyword rules below rely on it."""
    t = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower()


def tag(text: str, name: str) -> str | None:
    m = re.search(rf"<{name}(?:\s[^>]*)?>(.*?)</{name}>", text, re.DOTALL)
    return m.group(1).strip() if m else None


def tags(text: str, name: str) -> list[str]:
    return [m.strip() for m in re.findall(rf"<{name}(?:\s[^>]*)?>(.*?)</{name}>", text, re.DOTALL)]


HANDOFF_WORDS = ("nhan vien", "khieu nai", "phan nan", "gap nguoi", "tong dai", "nguoi that", "agent", "staff", "complain")
TRANSFER_WORDS = ("chuyen", "ck ", "gui tien", "chuyen khoan", "thanh toan", "nop tien", "tra tien", "transfer", "send ")
IMAGE_TRANSFER_MARKERS = ("stk", "so tai khoan", "chuyen khoan", "con phai nop", "qr", "ngan hang", "noi dung ck", "tai khoan nhan")
CANCEL_WORDS = (" thoi khong chuyen", " khong chuyen nua", " huy ", " huy di", " dung lai", " cancel ")
CONTINUE_WORDS = ("stk", "so tai khoan", "tai khoan", "dung la", "nham", "sua", "doi", "ngan hang", "bank", "nghin", "ngan", "tr", "k ")


def fake_intent(user_text: str, image_desc: str, task_open: bool) -> dict[str, str]:
    t, d = fold(user_text), fold(image_desc)
    padded = f"{t} "
    if any(w in t for w in HANDOFF_WORDS):
        return {"intent": "handoff.agent", "relation": "other" if task_open else "new", "reason": "yêu cầu gặp nhân viên"}
    wants_transfer = any(w in padded for w in TRANSFER_WORDS) or t.startswith("gui ")
    if any(w in f" {padded}" for w in CANCEL_WORDS):
        return {"intent": "transfer.domestic", "relation": "continue" if task_open else "new", "reason": "hủy yêu cầu chuyển tiền"}
    if image_desc:
        receipt_only = ("bien lai" in d or "giao dich thanh cong" in d) and not wants_transfer
        has_markers = any(m in d for m in IMAGE_TRANSFER_MARKERS) or bool(re.search(r"\d{8,}", d))
        no_info = "khong co thong tin chuyen tien" in d
        if receipt_only:
            return {"intent": "unknown", "relation": "other" if task_open else "new", "reason": "biên lai"}
        if wants_transfer or (has_markers and not no_info):
            return {"intent": "transfer.domestic", "relation": "continue" if task_open else "new", "reason": "ảnh thông tin chuyển tiền"}
        if no_info:
            return {"intent": "transfer.domestic", "relation": "new", "reason": "ảnh không đọc được thông tin"} if not task_open else {
                "intent": "unknown", "relation": "other", "reason": "ảnh không liên quan"}
    if wants_transfer:
        return {"intent": "transfer.domestic", "relation": "continue" if task_open else "new", "reason": "yêu cầu chuyển tiền"}
    if task_open and (re.search(r"\d{3,}", t) or any(w in f"{t} " for w in CONTINUE_WORDS)):
        return {"intent": "transfer.domestic", "relation": "continue", "reason": "bổ sung phiếu đang mở"}
    return {"intent": "unknown", "relation": "other" if task_open else "new", "reason": "không rõ"}


# ---------------------------------------------------------------- IMP-47 additions (not in the legacy fake)
NO_INFO_MARK = "khong co thong tin chuyen tien"  # the fake vision's line for an image without a sidecar
ACK = {"ok", "oke", "okay", "okie", "uh", "u", "um", "vang", "duoc", "dong y", "ok a", "vang a"}
REPEAT = ("nhac lai", "noi lai", "nhac ro", "noi ro", "lam ro", "hoi lai")


def no_new_info(user_text: str) -> bool:
    """"ok", "nhắc lại giúp": a turn that brings nothing for the task (nothing to extract)."""
    t = fold(user_text).strip(" .!?")
    return t in ACK or any(w in t for w in REPEAT)


QUESTION_CUES = ("?", "what is", "how much", "la gi", "nhu the nao", "the nao", "bao nhieu", "o dau", "bao lau", "lam sao", "can gi", "giay to", "co duoc khong",
                 "huong dan", "lai suat", "ty gia", "bieu phi", "giup duoc gi", "lam duoc gi")


def looks_like_question(user_text: str) -> bool:
    """A general question (IMP-69): a question cue and no amount or account number, so "chuyển mẹ 500k?" stays a transfer."""
    t = fold(user_text)
    return (any(c in t for c in QUESTION_CUES) or bool(re.search(r"\bphi\b", t))) and not _has_amount(t)


def _has_amount(t: str) -> bool:
    return bool(re.search(r"\d{3,}|\d+\s*(k|tr|trieu|nghin|ngan)\b", t))


# ---------------------------------------------------------------- IMP-70 / IMP-72: general and personal questions
PERSONAL_CUE = re.compile(r"cua toi|cua minh|toi con|tk cua|so du|giao dich (gan|lan cuoi|moi nhat)|tien (vao|ve) chua|luong ve")
NEED_RULES: tuple[tuple[str, str], ...] = (  # (need, folded-text pattern), in the order they are listed
    ("deposit_rate", r"lai suat|tiet kiem|gui tiet kiem"),
    ("exchange_rate", r"ty gia|\b(usd|eur|jpy|aud|cad|gbp|cny|sgd|krw|thb|chf)\b"),
    ("gold", r"\bvang\b"),
    ("fee", r"\bphi\b"),
    ("card", r"\bthe\b(?! nao)|\bvisa\b|\bmastercard\b|hoan tien"),  # "thế nào" folds to "the nao"
    ("promotion", r"khuyen mai|uu dai|\bkm\b"),
    ("howto", r"cach |lam sao|huong dan|sami"),
)
PERSONAL_RULES: tuple[tuple[str, str], ...] = (
    ("limit", r"han muc|con chuyen duoc"),
    ("balance", r"so du|con bao nhieu tien"),
    ("transactions", r"giao dich|tien (vao|ve)|luong"),
)


ENGLISH_NEED_RULES: tuple[tuple[str, str], ...] = (  # English words; "the" must not read as "thẻ" (folded)
    ("deposit_rate", r"interest|saving|deposit"),
    ("exchange_rate", r"exchange|\b(usd|eur|jpy|aud|cad|gbp|cny|sgd|krw|thb|chf)\b"),
    ("gold", r"\bgold\b"),
    ("fee", r"\bfees?\b"),
    ("card", r"\bcards?\b|\bvisa\b|\bmastercard\b|cashback"),
    ("promotion", r"promotion|\boffers?\b"),
    ("howto", r"how to|\bsami\b"),
)


def needs(t: str, rules: tuple[tuple[str, str], ...]) -> list[str]:
    """Kinds of data a question needs (folded text), at most four."""
    return [need for need, pattern in rules if re.search(pattern, t)][:4]


def fake_turn(user_text: str, image_desc: str, task_type: str | None) -> dict[str, Any]:
    """Step 1 of the understand prompt: legacy intent rules, then image relevance (IMP-47)."""
    out: dict[str, Any] = fake_intent(user_text, image_desc, task_type is not None)
    t = fold(user_text)
    open_to_question = not image_desc and out["intent"] in ("unknown", "transfer.domestic") and out["relation"] != "continue"
    if open_to_question and PERSONAL_CUE.search(t) and not _has_amount(t):  # before the faq rule: "số dư của tôi" is not a faq
        return {"intent": "account.inquiry", "relation": "other" if task_type else "new", "reason": "câu hỏi về tài khoản của khách",
                "faq_query": " ".join(user_text.split()), "needs": needs(t, PERSONAL_RULES)}
    if not image_desc and looks_like_question(user_text) and out["intent"] in ("unknown", "transfer.domestic") and out["relation"] != "continue":
        return {"intent": "faq.answer", "relation": "other" if task_type else "new", "reason": "câu hỏi thông tin",
                "faq_query": " ".join(user_text.split()), "needs": needs(t, ENGLISH_NEED_RULES if fake_language(user_text, []) == "en" else NEED_RULES)}
    if image_desc:
        out["image_relevant"] = NO_INFO_MARK not in fold(image_desc)
        if not out["image_relevant"] and not user_text.strip() and task_type is None:  # an irrelevant image alone
            out.update(intent="unknown", relation="new", reason="ảnh không liên quan")
    if no_new_info(user_text) and task_type is not None and out["intent"] == "unknown":  # "nhắc lại giúp" mid-task
        out.update(intent=task_type, relation="continue", reason="lượt trong task đang mở, không có thông tin mới")
    return out
