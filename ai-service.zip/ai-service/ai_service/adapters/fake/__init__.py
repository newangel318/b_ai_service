"""Offline adapters (LLM_PROVIDER=fake): deterministic, for tests and offline evals – not quality."""

from ai_service.adapters.fake.banks import BundledBanks
from ai_service.adapters.fake.llm import FakeLlmClient
from ai_service.adapters.fake.vision import FakeVisionClient

__all__ = ["BundledBanks", "FakeLlmClient", "FakeVisionClient"]
