"""Port implementations. Imported only by the composition root (ai_service/main.py)."""
