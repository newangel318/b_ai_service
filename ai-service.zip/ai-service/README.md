# ai-service

Stateless group-H service of Sami (Đặc tả `ai-service` API, `docs/ban_giao_2026_10_29/`): `POST /internal/ai/v1/understand`,
`/summarize`, `/answer`. Internal only – only `chat-service` calls it, with `X-Internal-Key`. Contract: `ai_service/contract/`
(Pydantic, source of truth) → `../contracts/ai-service.openapi.json`; fixtures in `../contracts/fixtures/`.

    uv sync && uv run pytest
    uv run ruff check . && uv run mypy
    uv run python -m scripts.export_openapi          # after any contract change
    uv run uvicorn ai_service.main:create --factory --port 8081

Container: `Dockerfile` (port 8081, internal only – compose gives it no host port and mounts `../testdata` for fake mode;
Azure gives it internal ingress, IMP-52).

Environment: `LLM_PROVIDER` (`fake` | `azure`), `AI_INTERNAL_KEY` (required with azure), `AI_DEBUG_TRACE`,
`AI_TOTAL_TIMEOUT_S` (15, one budget per call shared by the image read and the text call, IMP-55), `AI_MAX_IMAGE_BASE64_BYTES` (16 MiB),
`AZURE_OPENAI_*` (`…_DEPLOYMENT_TEXT`, falls back to `…_DEPLOYMENT_EXTRACT`), `CONTENT_SAFETY_*`, `FAKE_SIDECAR_DIRS`
(JSON list; default `../testdata/images`, `../testdata/real`). Decisions: `DECISIONS.md` IMP-39, IMP-41, IMP-42, IMP-46, IMP-48 (prompt versions are locked: `uv run python -m scripts.lock_versions` after adding a `.v<N+1>` file).
