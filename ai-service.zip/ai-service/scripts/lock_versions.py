"""Lock the content of every versioned prompt and intent registry (IMP-48). A locked version never changes: an edit is a
new ``.v<N+1>`` file, so ``meta.prompts`` names exactly what a request used.

Run: ``uv run python -m scripts.lock_versions`` (adds new files; refuses to change or drop a locked one).
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

CONFIG = Path(__file__).resolve().parents[1] / "config"
LOCK = "versions.lock"
VERSIONED = re.compile(r"prompts/[a-z0-9_]+\.v\d+\.md|intents\.v\d+\.yaml")


def versioned_files(config: Path) -> dict[str, str]:
    """Path relative to ``config`` -> sha256 of the bytes."""
    found: dict[str, str] = {}
    for p in sorted(config.rglob("*")):
        rel = p.relative_to(config).as_posix()
        if p.is_file() and VERSIONED.fullmatch(rel):
            found[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
    return found


def _lock(config: Path) -> dict[str, str]:
    path = config / LOCK
    return dict(json.loads(path.read_text(encoding="utf-8"))) if path.exists() else {}


def problems(config: Path) -> list[str]:
    lock, now = _lock(config), versioned_files(config)
    out = [f"{n}: changed after it was locked – put the change in a new version file" for n, h in now.items() if n in lock and lock[n] != h]
    out += [f"{n}: locked version is missing – versions are never deleted" for n in lock if n not in now]
    out += [f"{n}: not locked – run: uv run python -m scripts.lock_versions" for n in now if n not in lock]
    return out


def update(config: Path) -> list[str]:
    lock, now = _lock(config), versioned_files(config)
    refused = [p for p in problems(config) if "not locked" not in p]
    if refused:
        raise SystemExit("\n".join(refused))
    added = sorted(set(now) - set(lock))
    (config / LOCK).write_text(json.dumps({**lock, **{n: now[n] for n in added}}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return added


if __name__ == "__main__":
    for name in update(CONFIG):
        print("locked", name)
