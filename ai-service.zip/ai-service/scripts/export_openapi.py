"""Writes contracts/ai-service.openapi.json from the FastAPI app (Pydantic is the source; spec 8)."""

from __future__ import annotations

import json
from pathlib import Path

from ai_service.api.app import create_app

OPENAPI_PATH = Path(__file__).resolve().parents[2] / "contracts" / "ai-service.openapi.json"


def main() -> None:
    OPENAPI_PATH.write_text(json.dumps(create_app().openapi(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {OPENAPI_PATH.relative_to(OPENAPI_PATH.parents[1])}")


if __name__ == "__main__":
    main()
