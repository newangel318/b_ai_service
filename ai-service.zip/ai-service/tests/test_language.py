"""Language of a turn: the request wins; else what the model saw; else Vietnamese. Anything not Vietnamese is English."""

import pytest

from ai_service.adapters.fake.language import fake_language
from ai_service.understand.language import resolve_language


@pytest.mark.parametrize(("requested", "detected", "want"), [
    ("en", "vi", "en"), ("vi", "en", "vi"), (None, "en", "en"), (None, "vi", "vi"),
    (None, "fr", "en"), (None, None, "vi"), (None, "", "vi")])
def test_resolve_language(requested: str | None, detected: str | None, want: str) -> None:
    assert resolve_language(requested, detected) == want  # type: ignore[arg-type]


@pytest.mark.parametrize(("text", "earlier", "want"), [
    ("How much is the transfer fee?", [], "en"), ("Phí chuyển khoản bao nhiêu?", [], "vi"),
    ("500k", ["send money to mom"], "en"), ("ok", ["chuyển tiền cho mẹ"], "vi"), ("0123456789", [], "vi")])
def test_fake_language(text: str, earlier: list[str], want: str) -> None:
    assert fake_language(text, earlier) == want
