"""A version names fixed content (IMP-48): editing a locked prompt or registry fails here; a change is a new .v<N+1> file."""

from pathlib import Path

import pytest

from ai_service.capabilities import IntentCatalog
from ai_service.config import SERVICE_ROOT, Settings
from scripts.lock_versions import problems, update

CONFIG = SERVICE_ROOT / "config"


def test_every_versioned_file_matches_its_lock() -> None:
    assert problems(CONFIG) == []


def test_a_locked_version_cannot_change_or_vanish(tmp_path: Path) -> None:
    (tmp_path / "prompts").mkdir()
    a = tmp_path / "prompts" / "a.v1.md"
    a.write_text("v1", encoding="utf-8")
    assert update(tmp_path) == ["prompts/a.v1.md"] and problems(tmp_path) == []
    a.write_text("v1 edited", encoding="utf-8")
    assert "changed after it was locked" in problems(tmp_path)[0]
    with pytest.raises(SystemExit):
        update(tmp_path)
    a.write_text("v1", encoding="utf-8")
    (tmp_path / "prompts" / "a.v2.md").write_text("v2", encoding="utf-8")
    (tmp_path / "intents.v1.yaml").write_text("[]\n", encoding="utf-8")
    assert all("not locked" in p for p in problems(tmp_path)) and len(problems(tmp_path)) == 2
    assert update(tmp_path) == ["intents.v1.yaml", "prompts/a.v2.md"] and problems(tmp_path) == []
    a.unlink()
    assert "missing" in problems(tmp_path)[0]


def test_intent_registry_is_versioned_like_the_prompts(tmp_path: Path) -> None:
    for n, text in ((1, "cũ"), (2, "mới")):
        (tmp_path / f"intents.v{n}.yaml").write_text(f"- intent_id: x\n  description: {text}\n", encoding="utf-8")
    catalog = IntentCatalog(tmp_path)
    assert catalog.version == "intents.v2" and catalog.describe(["x"]) == "- x: mới"
    assert IntentCatalog(Settings().intents_dir).version == "intents.v6"
