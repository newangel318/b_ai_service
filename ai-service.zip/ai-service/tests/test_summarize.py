import pytest

from ai_service.contract.summarize import SummarizeRequest
from ai_service.errors import AiTimeout, Unavailable
from ai_service.ports import ModelUnavailable
from ai_service.understand.limits import Limits
from ai_service.understand.summarize import SummarizeService

from .doubles import ScriptedLlm, make_caps

SUMMARY = SummarizeRequest.model_validate({"request_id": "req_3", "purpose": "handoff", "previous_summary": "Khách hỏi phí.",
                                           "turns": [{"role": "user", "text": "cho gặp nhân viên"}]})


async def test_summary_renders_turns_and_purpose() -> None:
    llm = ScriptedLlm("Khách muốn gặp nhân viên.")
    res = await SummarizeService(make_caps(llm=llm), Limits()).summarize(SUMMARY)
    assert res.summary == "Khách muốn gặp nhân viên." and res.request_id == "req_3"
    system, user = llm.calls[0]["messages"]
    assert "để chuyển cho nhân viên hỗ trợ" in system.content and "Khách hàng: cho gặp nhân viên" in user.content
    assert "<session_summary>" in user.content and res.meta.prompt_version == "summarize.v1"


async def test_summary_timeout_is_504() -> None:
    with pytest.raises(AiTimeout):
        await SummarizeService(make_caps(llm=ScriptedLlm("x", delay_s=0.5)), Limits(total_timeout_s=0.05)).summarize(SUMMARY)


async def test_summary_model_down_is_503() -> None:
    with pytest.raises(Unavailable):
        await SummarizeService(make_caps(llm=ScriptedLlm(error=ModelUnavailable("down"))), Limits()).summarize(SUMMARY)
