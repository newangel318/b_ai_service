"""The /understand fixture eval scores the model's answer key by key and never drops a fixture silently."""

from __future__ import annotations

import copy
from typing import Any

from evals.understand_fixtures import URL, evaluate, render, score, skip_reason

from .fixtures_util import load_understand_fixtures

ALL = load_understand_fixtures()


def test_scoring_ignores_evidence_wording_and_candidate_order() -> None:
    want = {"intent": "transfer.domestic", "fields": {"amount": [{"value": 500000, "evidence": "500k", "from": "text"}]}}
    same = {"intent": "transfer.domestic", "fields": {"amount": [{"value": 500000, "evidence": "500 nghìn", "from": "text"}]}}
    other = {"intent": "transfer.domestic", "fields": {"amount": [{"value": 50000, "evidence": "50k", "from": "text"}]}}
    assert score(want, same) == []
    assert score(want, other) == ["fields.amount"]
    assert score({"intent": "unknown", "fields": {}, "secondary": []}, {"intent": "unknown"}) == []  # empty = absent


def test_image_and_negative_fixtures_are_skipped_with_a_reason() -> None:
    skipped = {f.name: skip_reason(f) for f in ALL if skip_reason(f)}
    assert len(skipped) == 12 and len(ALL) - len(skipped) == 17
    assert "image" in (skipped["01_vietqr_new_task"] or "") and "negative" in (skipped["n1_qr_only_evidence"] or "")


def test_an_answer_equal_to_the_fixture_passes_every_scored_fixture() -> None:
    by_name = {f.name: f for f in ALL}

    def echo(req: dict[str, Any]) -> tuple[int, dict[str, Any]]:  # evaluate sets request_id = "req_<fixture name>"
        return 200, copy.deepcopy(by_name[req["request_id"].removeprefix("req_")].response)

    results = evaluate(echo, ALL)
    scored = [r for r in results if r.skipped is None]
    assert len(scored) == 17 and all(r.status == 200 and r.mismatches == [] for r in scored)
    report = render(results, "fake")
    assert "Fake mode" in report and "17/17" in report and "01_vietqr_new_task" in report  # skipped ones are listed


def test_a_failed_answer_is_reported_with_its_status() -> None:
    results = evaluate(lambda req: (503, {"error": {"code": "AI_UNAVAILABLE"}}), ALL)
    failed = [r for r in results if r.skipped is None]
    assert failed and all(r.status == 503 and r.mismatches == ["status 503"] for r in failed)
    assert "status 503" in render(results, "azure") and "Fake mode" not in render(results, "azure")


def test_each_field_is_scored_on_its_own_so_a_junk_note_does_not_hide_a_right_amount() -> None:
    want = {"intent": "transfer.domestic", "fields": {"amount": [{"value": 500000}], "reference": [{"value": "tiền chợ"}]}}
    junk_note = {"intent": "transfer.domestic", "fields": {"amount": [{"value": 500000}], "reference": [{"value": "ấy"}]}}
    wrong_amount = {"intent": "transfer.domestic", "fields": {"amount": [{"value": 50000}], "reference": [{"value": "tiền chợ"}]}}
    assert score(want, junk_note) == ["fields.reference"]
    assert score(want, wrong_amount) == ["fields.amount"]
    assert score(want, {**want, "fields": {**want["fields"], "reference": [{"value": "  Tiền  chợ "}]}}) == []  # case, spaces


def test_free_text_wording_of_an_objection_is_not_scored() -> None:
    want = {"intent": "transfer.domestic", "objection": {"field": "account_no", "claim": "số cuối là 89"}}
    got = {"intent": "transfer.domestic", "objection": {"field": "account_no", "claim": "khách nói số cuối 89"}}
    assert score(want, got) == []
    assert score(want, {**got, "objection": {"field": "amount", "claim": "x"}}) == ["objection"]


def test_every_request_runs_on_one_event_loop() -> None:
    # The Azure SDK's async HTTP pool is bound to the loop of its first request: a new loop per request failed every
    # second call with 503 AI_UNAVAILABLE (fixture eval on Azure, 2026-10-15).
    import asyncio

    from fastapi import FastAPI

    from evals.understand_fixtures import app_poster

    app = FastAPI()
    loops: list[int] = []

    @app.post(URL)
    async def understand() -> dict[str, str]:
        loops.append(id(asyncio.get_running_loop()))
        return {}

    with app_poster(app, {}) as post:
        assert post({})[0] == 200 and post({})[0] == 200
    assert len(set(loops)) == 1


def test_a_server_error_is_a_scored_500_not_a_crash() -> None:
    from fastapi import FastAPI

    from evals.understand_fixtures import app_poster

    app = FastAPI()

    @app.post(URL)
    async def understand() -> dict[str, str]:
        raise RuntimeError("boom")

    with app_poster(app, {}) as post:
        assert post({})[0] == 500
