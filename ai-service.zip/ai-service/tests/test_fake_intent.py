"""Fake understand rules for general and personal questions (IMP-70, IMP-72): intent, faq_query and needs."""

from typing import Any

import pytest

from ai_service.adapters.fake.intent import fake_turn


def turn(text: str) -> dict[str, Any]:
    return fake_turn(text, "", None)


@pytest.mark.parametrize("text,need", [
    ("Lãi suất tiết kiệm 12 tháng là bao nhiêu?", "deposit_rate"),
    ("lai suat tiet kiem 12 thang bnhieu", "deposit_rate"),
    ("tỷ giá USD hôm nay", "exchange_rate"),
    ("Giá vàng thì sao?", "gold"),
    ("ngân hàng có tính phí chuyển khoản không?", "fee"),
    ("phí thường niên thẻ visa platinum", "card"),
    ("thẻ nào được hoàn tiền?", "card"),
    ("đang có khuyến mãi gì?", "promotion"),
])
def test_general_questions_name_their_needs(text: str, need: str) -> None:
    out = turn(text)
    assert out["intent"] == "faq.answer" and need in out["needs"] and out["faq_query"] == " ".join(text.split())


def test_a_plain_question_needs_nothing_specific() -> None:
    assert turn("Mở tài khoản cần giấy tờ gì?")["needs"] == []
    assert "card" not in turn("chuyển tiền quốc tế như thế nào?")["needs"]  # "thế nào" is not "thẻ"


@pytest.mark.parametrize("text,need", [
    ("hiện tại hạn mức chuyển khoản của tôi là bao nhiêu", "limit"),
    ("số dư hiện tại?", "balance"),
    ("giao dịch lần cuối", "transactions"),
    ("lương về chưa", "transactions"),
])
def test_personal_questions(text: str, need: str) -> None:
    out = turn(text)
    assert out["intent"] == "account.inquiry" and out["needs"] == [need] and out["faq_query"]


def test_general_sami_limit_stays_faq() -> None:
    assert turn("Hạn mức chuyển tiền qua Sami một ngày là bao nhiêu?")["intent"] == "faq.answer"


def test_transfer_with_amount_stays_a_transfer() -> None:
    assert turn("chuyển mẹ 500k")["intent"] == "transfer.domestic"


def test_what_sami_can_do_is_a_question() -> None:
    assert turn("bạn giúp được gì")["intent"] == "faq.answer"


def test_english_questions_and_requests() -> None:  # the fake does not translate: faq_query stays the English text
    assert turn("send 2 million to 0123456789 at Vietcombank")["intent"] == "transfer.domestic"
    assert turn("I want to talk to an agent")["intent"] == "handoff.agent"
    out = turn("What is the transfer fee?")
    assert out["intent"] == "faq.answer" and out["needs"] == ["fee"] and out["faq_query"] == "What is the transfer fee?"
