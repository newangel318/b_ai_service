import hashlib
import json
from pathlib import Path

import pytest

from ai_service.adapters.fake.amount import parse_amount
from ai_service.adapters.fake.banks import DATA, BundledBanks
from ai_service.adapters.fake.vision import NO_INFO, FakeVisionClient

ROOT = Path(__file__).resolve().parents[2]
IMAGES = ROOT / "testdata" / "images"


def _image_with(suffix: str) -> Path:
    return next(p for p in sorted(IMAGES.glob("*.jpg")) if (IMAGES / (p.stem + suffix)).exists())


async def test_sidecar_is_found_by_the_image_bytes_not_the_name() -> None:
    img = _image_with(".desc.txt")
    res = await FakeVisionClient([IMAGES]).describe(use_case="sami.understand_image", system="", user_text="", image_bytes=img.read_bytes(),
                                                    mime="image/jpeg")
    assert res.text == (IMAGES / (img.stem + ".desc.txt")).read_text(encoding="utf-8").strip()
    assert res.deployment == "fake-vision"


async def test_unknown_image_has_no_information(tmp_path: Path) -> None:
    res = await FakeVisionClient([tmp_path, tmp_path / "missing"]).describe(use_case="sami.understand_image", system="", user_text="",
                                                                            image_bytes=b"not in the index", mime="image/png")
    assert res.text == NO_INFO == "TÓM TẮT: Ảnh không có thông tin chuyển tiền."


def test_index_keys_are_sha256(tmp_path: Path) -> None:
    (tmp_path / "a.png").write_bytes(b"abc")
    (tmp_path / "a.desc.txt").write_text("TÓM TẮT: A", encoding="utf-8")
    client = FakeVisionClient([tmp_path])
    assert hashlib.sha256(b"abc").hexdigest() in client.index


async def test_banks_are_found_in_free_text() -> None:
    banks = BundledBanks.load()
    assert [b.name for b in await banks.find_in_text("chuyển qua vietcom giúp em")] == ["Vietcombank"]
    assert await banks.code_for_name("MB") == "MBB"
    assert await banks.code_for_name(None) is None


def test_bundled_banks_match_their_sources() -> None:  # drift guard while the sources live in this repo
    src = ROOT / "sacompay-mock" / "sacompay_mock" / "data" / "banks.json"
    if not src.exists():
        pytest.skip("source data not in this checkout")
    bundled = json.loads(DATA.read_text(encoding="utf-8"))
    assert sorted(b["bank_code"] for b in bundled["banks"]) == sorted(b["bankCode"] for b in json.loads(src.read_text(encoding="utf-8")))


def test_copied_amount_parser_works() -> None:
    assert parse_amount("1tr2") == 1_200_000 and parse_amount("500k") == 500_000
    assert parse_amount("1.5k") == 1_500 and parse_amount("1,100k") == 1_100_000 and parse_amount("1.5") is None  # owner 2026-10-21


async def test_an_image_written_after_start_is_found(tmp_path: Path) -> None:  # chat-service's e2e writes images while running
    client = FakeVisionClient([tmp_path])
    (tmp_path / "late.png").write_bytes(b"late image")
    (tmp_path / "late.desc.txt").write_text("TÓM TẮT: Ảnh viết sau.", encoding="utf-8")
    res = await client.describe(use_case="sami.understand_image", system="", user_text="", image_bytes=b"late image", mime="image/png")
    assert res.text == "TÓM TẮT: Ảnh viết sau."
