import json
from pathlib import Path

from fastapi.testclient import TestClient

from ai_service.api.app import create_app

OPENAPI = Path(__file__).resolve().parents[2] / "contracts" / "ai-service.openapi.json"


def test_published_openapi_is_current() -> None:
    """Regenerate with: cd ai-service && uv run python -m scripts.export_openapi"""
    assert json.loads(OPENAPI.read_text(encoding="utf-8")) == create_app().openapi()


def test_app_without_services_answers_503() -> None:
    client = TestClient(create_app())
    res = client.post("/internal/ai/v1/understand", json={"request_id": "req_1", "turn_id": "trn_1", "intents_enabled": ["unknown"],
                                                          "message": {"text": "alo"}})
    assert res.status_code == 503 and res.json()["error"]["code"] == "AI_UNAVAILABLE"
    assert client.get("/internal/ai/v1/openapi.json").status_code == 200


def test_off_schema_request_is_400_ai_bad_request() -> None:  # spec 5: 422 is reserved for AI_OUTPUT_INVALID
    res = TestClient(create_app()).post("/internal/ai/v1/understand", json={"customer_id": "demo-001"})
    assert res.status_code == 400
    assert res.json()["error"]["code"] == "AI_BAD_REQUEST" and res.json()["error"]["retryable"] is False
