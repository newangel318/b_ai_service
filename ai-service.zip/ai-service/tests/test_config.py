import pytest
from pydantic import ValidationError

from ai_service.config import SERVICE_ROOT, Settings


def test_defaults_are_offline_and_parametrised() -> None:
    s = Settings()
    assert s.llm_provider == "fake" and s.ai_internal_key == "" and s.ai_debug_trace is False
    assert s.ai_total_timeout_s == 15.0  # one budget per group-H call, image or not (IMP-55)
    assert not hasattr(s, "ai_vision_timeout_s") and not hasattr(s, "ai_text_timeout_s")
    assert s.ai_max_image_base64_bytes == 16 * 1024 * 1024
    assert s.prompts_dir == SERVICE_ROOT / "config" / "prompts"
    assert SERVICE_ROOT.name == "ai-service"


def test_azure_needs_an_internal_key() -> None:
    with pytest.raises(ValidationError, match="AI_INTERNAL_KEY"):
        Settings(llm_provider="azure")
    assert Settings(llm_provider="azure", ai_internal_key="k").llm_provider == "azure"


def test_text_deployment_falls_back_to_the_old_extract_variable(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_EXTRACT", "gpt-old")
    assert Settings().azure_openai_deployment_text == "gpt-old"
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_TEXT", "gpt-new")
    assert Settings().azure_openai_deployment_text == "gpt-new"


def test_an_empty_text_variable_does_not_hide_the_old_extract_one(monkeypatch: pytest.MonkeyPatch) -> None:
    # .env from .env.example keeps "AZURE_OPENAI_DEPLOYMENT_TEXT=" empty; an old setup fills only …_EXTRACT (IMP-52 (2)).
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_TEXT", "")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_EXTRACT", "gpt-old")
    assert Settings().azure_openai_deployment_text == "gpt-old"
