from typing import Any

import pytest

from ai_service.contract import UnderstandRequest, UnderstandResponse

from .fixtures_util import ResolvedFixture, load_understand_fixtures, merge_patch

ALL = load_understand_fixtures()
FIXTURES = [f for f in ALL if f.name[0].isdigit()]  # the spec §8 examples; n* are negative cases


def test_merge_patch_rfc7386() -> None:
    assert merge_patch({"a": 1, "b": {"c": 2, "d": 3}}, {"b": {"c": None, "e": 4}, "f": [1]}) == {"a": 1, "b": {"d": 3, "e": 4}, "f": [1]}


def test_every_spec_example_is_present() -> None:
    assert len(FIXTURES) == 21


@pytest.mark.parametrize("fx", ALL, ids=lambda f: f.name)
def test_fixture_matches_the_contract_exactly(fx: ResolvedFixture) -> None:
    req = UnderstandRequest.model_validate(fx.request)
    res = UnderstandResponse.model_validate(fx.response)
    assert req.model_dump(mode="json", exclude_unset=True) == fx.request  # nothing renamed or dropped
    assert res.model_dump(mode="json", exclude_unset=True) == fx.response


def _without_qr_lines(text: str) -> str:
    """chat-service drops the [QR n – …] lines ai-service adds: QR data only from its own decoder (IMP-41 (4), spec 4.3)."""
    return "\n".join(line for line in text.splitlines() if not line.strip().startswith("[QR "))


def _image_texts(fx: ResolvedFixture) -> str:
    texts = [d["description"] for d in (fx.request.get("task_state") or {}).get("image_descriptions", [])]
    texts.append((fx.response.get("image") or {}).get("description") or "")
    return _without_qr_lines("\n".join(texts))


@pytest.mark.parametrize("fx", ALL, ids=lambda f: f.name)
def test_evidence_is_verbatim(fx: ResolvedFixture) -> None:  # spec 4.3, what chat-service will check
    text = fx.request["message"].get("text", "")
    for name, cands in fx.response.get("fields", {}).items():
        ok = all(c["evidence"] in (text if c["from"] == "text" else _image_texts(fx)) for c in cands)
        assert ok == (f"fields.{name}" not in fx.expect_rejected), (fx.name, name)
    for key in ("option_choice", "amount_ref", "objection", "source_account"):
        if fx.response.get(key):
            assert fx.response[key]["evidence"] in text, (fx.name, key)


def _refs_ok(fx: ResolvedFixture) -> dict[str, bool]:
    """Which model references point at something the request really contained (spec 4.3)."""
    req, res = fx.request, fx.response
    out: dict[str, bool] = {}
    choice: dict[str, Any] | None = res.get("option_choice")
    if choice:
        shown = ((req.get("task_state") or {}).get("last_question") or {}).get("options", [])
        out["option_choice"] = any(o["ref"] == choice.get("ref") and o["index"] == choice.get("index") for o in shown)
    if res.get("source_account"):
        out["source_account"] = res["source_account"]["account_ref"] in {a["account_ref"] for a in ctx.get("source_accounts", [])}
    return out


@pytest.mark.parametrize("fx", ALL, ids=lambda f: f.name)
def test_refs_point_into_the_request(fx: ResolvedFixture) -> None:
    for key, ok in _refs_ok(fx).items():
        assert ok == (key not in fx.expect_rejected), (fx.name, key)


def test_negative_fixtures_cover_every_reference_kind() -> None:
    rejected = {r for fx in ALL for r in fx.expect_rejected}
    assert {"fields.account_no", "option_choice", "amount_ref", "source_account"} <= rejected
