from typing import Any

import pytest
from pydantic import ValidationError

from ai_service.contract import SummarizeResponse, UnderstandRequest, UnderstandResponse
from ai_service.contract.common import Candidate

FORBIDDEN_IN_RESPONSES = {"phase", "draft_status", "tb_code", "transfer_request", "customer_id"}


def request(**over: Any) -> dict[str, Any]:
    body: dict[str, Any] = {
        "schema_version": 1, "request_id": "req_1", "turn_id": "trn_1",
        "intents_enabled": ["transfer.domestic", "unknown"],
        "message": {"text": "chuyển 500k"},
        "history": {"turns": []},
        "customer_context": {"source_accounts": [{"account_ref": "acc_1", "alias": "TK thanh toán"}]},
    }
    body.update(over)
    return body


def test_minimal_request_is_valid() -> None:
    req = UnderstandRequest.model_validate(request())
    assert req.task_state is None and req.message.image is None and req.language is None


def test_request_never_carries_customer_identity() -> None:  # U4
    with pytest.raises(ValidationError):
        UnderstandRequest.model_validate(request(customer_id="demo-001"))


def test_customer_context_rejects_payees() -> None:
    ctx = {"payees": [{"beneficiary_id": "ben_101", "nickname": "Mẹ"}]}
    with pytest.raises(ValidationError):
        UnderstandRequest.model_validate(request(customer_context=ctx))


def test_message_needs_text_or_image() -> None:
    with pytest.raises(ValidationError, match="text or an image"):
        UnderstandRequest.model_validate(request(message={"text": "  "}))


def test_candidate_uses_the_from_key_on_the_wire() -> None:
    c = Candidate.model_validate({"value": 500000, "evidence": "500k", "from": "text"})
    assert c.from_ == "text" and c.model_dump(by_alias=True) == {"value": 500000, "evidence": "500k", "from": "text"}


def _property_names(schema: dict[str, Any]) -> set[str]:
    names: set[str] = set()
    for node in [schema, *schema.get("$defs", {}).values()]:
        names |= set(node.get("properties", {}))
    return names


@pytest.mark.parametrize("model", [UnderstandResponse, SummarizeResponse])
def test_responses_carry_no_business_decisions(model: type[Any]) -> None:  # U3
    assert not FORBIDDEN_IN_RESPONSES & _property_names(model.model_json_schema(by_alias=True))


def test_understand_response_top_level_has_no_status() -> None:
    assert "status" not in UnderstandResponse.model_json_schema()["properties"]


def test_qr_index_is_optional() -> None:  # IMP-42: spec examples leave it out
    from ai_service.contract.understand import QrIn

    assert QrIn.model_validate({"kind": "VIETQR_TRANSFER", "crc_valid": True}).index is None


def response(**over: Any) -> dict[str, Any]:
    body: dict[str, Any] = {"request_id": "req_1", "intent": "transfer.domestic", "relation": "new", "change_type": "fill",
                            "meta": {"prompt_version": "understand.v3"}}
    body.update(over)
    return body


@pytest.mark.parametrize("fields", [
    {"amount": [{"value": "500k", "evidence": "500k", "from": "text"}]},          # amount must be an int
    {"amount": [{"value": 0, "evidence": "0đ", "from": "text"}]},                 # and positive
    {"amount": [{"value": True, "evidence": "500k", "from": "text"}]},            # not a bool
    {"account_no": [{"value": 601000888999, "evidence": "0601000888999", "from": "text"}]},  # int loses the leading zero
    {"bank": [{"value": 970436, "evidence": "970436", "from": "text"}]},
])
def test_candidate_values_are_typed_per_field(fields: dict[str, Any]) -> None:
    with pytest.raises(ValidationError):
        UnderstandResponse.model_validate(response(fields=fields))


@pytest.mark.parametrize("status", ["TIMEOUT", "ERROR"])
def test_failed_image_read_carries_no_candidates(status: str) -> None:  # IMP-38: the whole turn fails
    with pytest.raises(ValidationError, match="no candidates"):
        UnderstandResponse.model_validate(response(image={"status": status},
                                                   fields={"amount": [{"value": 300000, "evidence": "300k", "from": "text"}]}))


def test_not_a_document_keeps_text_candidates_only() -> None:
    ok = response(image={"status": "NOT_A_DOCUMENT"}, fields={"amount": [{"value": 300000, "evidence": "300k", "from": "text"}]})
    assert UnderstandResponse.model_validate(ok).fields["amount"][0].value == 300000
    with pytest.raises(ValidationError, match="from the image"):
        UnderstandResponse.model_validate(response(image={"status": "NOT_A_DOCUMENT"},
                                                   fields={"bank": [{"value": "ACB", "evidence": "ACB", "from": "image"}]}))


def test_meta_lists_every_prompt_used() -> None:  # IMP-46 (1)
    from ai_service.contract.common import Meta

    used = {"understand_image": "understand_image.v1", "understand": "understand.v4", "intent_transfer_domestic": "intent_transfer_domestic.v2"}
    assert Meta(prompt_version="understand.v4", prompts=used).model_dump(mode="json")["prompts"] == used


def test_unauthorized_is_an_error_code() -> None:  # IMP-46 (1)
    from ai_service.contract import ErrorDetail

    assert ErrorDetail(code="AI_UNAUTHORIZED", message="x", retryable=False).code == "AI_UNAUTHORIZED"
