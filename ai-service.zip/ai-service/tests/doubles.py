"""Model-client doubles for offline tests (not adapters: they live with the tests)."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from ai_service.capabilities import Capabilities, Pricing, PromptLibrary
from ai_service.ports import ChatMessage, ModelResult, ShieldResult, Usage

SERVICE_ROOT = Path(__file__).resolve().parents[1]
PROMPTS = SERVICE_ROOT / "config" / "prompts"
INTENTS = SERVICE_ROOT / "config"
TINY_PNG_B64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="


class ScriptedVision:
    def __init__(self, text: str = "TÓM TẮT: Ảnh hóa đơn tiền điện.", *, delay_s: float = 0.0, error: Exception | None = None) -> None:
        self.text, self.delay_s, self.error = text, delay_s, error
        self.calls: list[dict[str, Any]] = []

    async def describe(self, *, use_case: str, system: str, user_text: str, image_bytes: bytes, mime: str) -> ModelResult:
        self.calls.append({"use_case": use_case, "user_text": user_text, "bytes": len(image_bytes), "mime": mime})
        if self.delay_s:
            await asyncio.sleep(self.delay_s)
        if self.error:
            raise self.error
        return ModelResult(text=self.text, usage=Usage(100, 40), latency_ms=7, deployment="vision-dep")


class ScriptedLlm:
    """Returns the scripted outputs in order (the last one repeats)."""

    def __init__(self, *outputs: str | dict[str, Any], delay_s: float = 0.0, error: Exception | None = None) -> None:
        self.outputs = [o if isinstance(o, str) else json.dumps(o, ensure_ascii=False) for o in outputs] or ['{"intent": "unknown"}']
        self.delay_s, self.error = delay_s, error
        self.calls: list[dict[str, Any]] = []

    async def complete(self, *, use_case: str, messages: list[ChatMessage], response_model: type[BaseModel] | None = None) -> ModelResult:
        self.calls.append({"use_case": use_case, "messages": messages})
        if self.delay_s:
            await asyncio.sleep(self.delay_s)
        if self.error:
            raise self.error
        text = self.outputs[min(len(self.calls), len(self.outputs)) - 1]
        return ModelResult(text=text, usage=Usage(300, 60), latency_ms=11, deployment="text-dep")


class ScriptedShield:
    def __init__(self, result: ShieldResult | None = None, *, error: Exception | None = None) -> None:
        self.result, self.error = result or ShieldResult(), error
        self.calls: list[tuple[str, list[str]]] = []

    async def analyze(self, user_text: str, documents: list[str]) -> ShieldResult:
        self.calls.append((user_text, documents))
        if self.error:
            raise self.error
        return self.result


def make_caps(vision: ScriptedVision | None = None, llm: ScriptedLlm | None = None, shield: ScriptedShield | None = None,
              pricing: Pricing | None = None) -> Capabilities:
    return Capabilities(vision or ScriptedVision(), llm or ScriptedLlm(), PromptLibrary(PROMPTS), pricing or Pricing(None), shield)


def make_services(vision: ScriptedVision | None = None, llm: ScriptedLlm | None = None, shield: ScriptedShield | None = None,
                  limits: Any = None) -> Any:
    from ai_service.api.app import Services
    from ai_service.capabilities import IntentCatalog
    from ai_service.understand.answer import AnswerService
    from ai_service.understand.limits import Limits
    from ai_service.understand.service import UnderstandService
    from ai_service.understand.summarize import SummarizeService

    caps, lim = make_caps(vision, llm, shield), limits or Limits()
    return Services(UnderstandService(caps, IntentCatalog(INTENTS), lim), SummarizeService(caps, lim),
                    AnswerService(caps, lim))
