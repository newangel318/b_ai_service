import json
from typing import Any

from ai_service.adapters.fake.banks import BundledBanks
from ai_service.adapters.fake.llm import FakeLlmClient
from ai_service.contract.understand import UnderstandRequest
from ai_service.ports import ChatMessage
from ai_service.understand.render import render_messages

from .doubles import TINY_PNG_B64
from .fixtures_util import load_understand_fixtures

FX = {f.name: f for f in load_understand_fixtures()}
LLM = FakeLlmClient(BundledBanks.load())


async def understand(text: str, *, base: str = "18_unknown", description: str | None = None) -> dict[str, Any]:
    """``description`` given = the turn carries a new image whose (QR-annotated) text is ``description``."""
    message: dict[str, Any] = {"text": text}
    if description is not None:
        message["image"] = {"image_id": "img_t", "media_type": "image/png", "data_base64": TINY_PNG_B64, "qr": []}
    req = UnderstandRequest.model_validate({**FX[base].request, "message": message})
    res = await LLM.complete(use_case="sami.understand", messages=render_messages(req, description))
    out: dict[str, Any] = json.loads(res.text)
    return out


async def test_amount_from_text_for_a_new_transfer() -> None:
    out = await understand("chuyển 500k", description="TÓM TẮT: Ảnh mã VietQR.\n[QR 1 – QR thanh toán khác]")
    assert out["intent"] == "transfer.domestic" and out["change_type"] == "fill"
    assert out["fields"]["amount"] == [{"value": 500000, "evidence": "500k", "from": "text"}]


async def test_payee_data_is_not_processed_by_ai_service() -> None:
    out = await understand("chuyển mẹ 1tr2 tiền chợ")
    assert "payee" not in out
    assert out["fields"]["amount"][0]["value"] == 1_200_000
    assert out["fields"]["reference"][0]["value"] == "tiền chợ"


async def test_names_are_not_resolved_by_ai_service() -> None:
    out = await understand("chuyển anh Nam bên MB 300k")
    assert "payee" not in out and out["fields"]["amount"][0]["value"] == 300_000


async def test_like_last_time_is_left_for_chat_service() -> None:
    out = await understand("chuyển Lan như lần trước")
    assert "amount_ref" not in out and "amount" not in out["fields"]


async def test_salary_account_by_its_reference() -> None:
    out = await understand("chuyển mẹ 2tr từ tài khoản lương")
    assert out["source_account"] == {"account_ref": "acc_2", "evidence": "tài khoản lương"}


async def test_cancel_with_an_open_task() -> None:
    out = await understand("thôi không chuyển nữa", base="09_cancel")
    assert (out["intent"], out["relation"], out["change_type"]) == ("transfer.domestic", "continue", "cancel")


async def test_other_intents_have_no_candidates() -> None:
    out = await understand("cho tôi gặp nhân viên")
    assert out["intent"] == "handoff.agent" and out["fields"] == {} and out["change_type"] == "none"


async def test_qr_lines_are_never_evidence() -> None:
    out = await understand("", description="TÓM TẮT: Ảnh mã VietQR.\n[QR 1 – VietQR chuyển tiền, tĩnh, hợp lệ] BIN 970436 · Tới: tài khoản · "
                                           "STK: 0601000888999 · Số tiền: 200000 · Nội dung: không có")
    assert all("[QR" not in c["evidence"] for cands in out["fields"].values() for c in cands)


async def test_image_candidates_come_from_description_lines() -> None:
    desc = "TÓM TẮT: Ảnh thông tin chuyển khoản.\nNgân hàng: Vietcombank\nSố tài khoản: 0181003561026\nChủ tài khoản: NGUYEN VAN A"
    out = await understand("", description=desc)
    assert out["fields"]["account_no"] == [{"value": "0181003561026", "evidence": "Số tài khoản: 0181003561026", "from": "image"}]
    assert out["fields"]["recipient_name_on_image"][0]["value"] == "NGUYEN VAN A"


async def test_an_irrelevant_image_alone_is_unknown() -> None:  # IMP-47
    out = await understand("", description="TÓM TẮT: Ảnh không có thông tin chuyển tiền.")
    assert (out["intent"], out["image_relevant"], out["fields"]) == ("unknown", False, {})


async def test_an_irrelevant_image_with_a_transfer_text_keeps_the_text() -> None:
    out = await understand("chuyển 300k cho Lan", description="TÓM TẮT: Ảnh không có thông tin chuyển tiền.")
    assert (out["intent"], out["image_relevant"]) == ("transfer.domestic", False)
    assert out["fields"]["amount"][0]["value"] == 300_000 and "payee" not in out


async def test_a_transfer_image_is_relevant() -> None:
    out = await understand("", description="TÓM TẮT: Ảnh thông tin chuyển khoản.\nSố tài khoản: 0181003561026")
    assert (out["intent"], out["image_relevant"]) == ("transfer.domestic", True)


async def test_ok_and_repeat_requests_stay_in_the_open_task_without_candidates() -> None:
    for text in ("ok", "bạn nhắc rõ lại yêu cầu xem"):
        out = await understand(text, base="09_cancel")
        assert (out["intent"], out["relation"], out["change_type"], out["fields"]) == ("transfer.domestic", "continue", "none", {}), text
        assert "act" not in out  # /understand only classifies and extracts (IMP-47 (6))


async def test_summarize_is_deterministic_text() -> None:
    res = await LLM.complete(use_case="sami.summarize", messages=[ChatMessage("system", "x"), ChatMessage("user", "Khách hàng: alo")])
    assert res.text.startswith("Khách hàng trao đổi với Sami.")
