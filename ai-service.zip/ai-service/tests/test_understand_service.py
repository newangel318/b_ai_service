import json
from pathlib import Path
from typing import Any

import pytest
from structlog.testing import capture_logs

from ai_service.capabilities import IntentCatalog
from ai_service.contract.understand import UnderstandRequest
from ai_service.errors import AiTimeout, BadRequest, ImageTooLarge, RateLimited
from ai_service.ports import ModelRateLimited, ModelUnavailable, ShieldResult
from ai_service.understand.limits import Limits
from ai_service.understand.service import UnderstandService

from .doubles import INTENTS, TINY_PNG_B64, ScriptedLlm, ScriptedShield, ScriptedVision, make_caps

VIETQR = {"index": 1, "kind": "VIETQR_TRANSFER", "crc_valid": True, "static": True, "account_type": "account",
          "parsed": {"bank_bin": "970436", "account_no": "0601000888999"}}
TEXT_AMOUNT = {"amount": [{"value": 300000, "evidence": "300k", "from": "text"}]}
IMAGE_ACCOUNT = {"account_no": [{"value": "0181003561026", "evidence": "STK 0181003561026", "from": "image"}]}


def request(text: str = "chuyển 300k", *, enabled: list[str] | None = None, image: bool = False, qr: list[dict[str, Any]] | None = None, b64: str = TINY_PNG_B64,
            language: str | None = None) -> UnderstandRequest:
    message: dict[str, Any] = {"text": text}
    if image:
        message["image"] = {"image_id": "img_1", "media_type": "image/png", "data_base64": b64, "qr": qr or []}
    extra = {"language": language} if language else {}
    return UnderstandRequest.model_validate({"request_id": "req_1", "turn_id": "trn_1", "message": message, **extra,
                                             "intents_enabled": enabled or ["transfer.domestic", "faq.answer", "unknown"]})


def service(vision: ScriptedVision | None = None, llm: ScriptedLlm | None = None, shield: ScriptedShield | None = None,
            limits: Limits | None = None) -> UnderstandService:
    return UnderstandService(make_caps(vision, llm, shield), IntentCatalog(INTENTS), limits or Limits())


def transfer(**extra: Any) -> dict[str, Any]:
    return {"intent": "transfer.domestic", "relation": "new", "change_type": "fill", "fields": TEXT_AMOUNT, **extra}


async def test_text_turn_makes_one_text_call_and_echoes_the_request_id() -> None:
    vision, llm = ScriptedVision(), ScriptedLlm(transfer(reason="Khách muốn chuyển 300k"))
    res = await service(vision, llm).understand(request())
    assert vision.calls == [] and [c["use_case"] for c in llm.calls] == ["sami.understand"]
    assert res.request_id == "req_1" and res.image is None and res.fields["amount"][0].value == 300000
    assert res.meta.prompt_version == "understand.v4"
    assert res.meta.prompts == {"understand": "understand.v4", "intent_transfer_domestic": "intent_transfer_domestic.v2",
                                "intent_faq_answer": "intent_faq_answer.v5", "intents": "intents.v6"}  # IMP-48
    assert "- transfer.domestic:" in llm.calls[0]["messages"][0].content and res.debug is None


async def test_image_turn_appends_qr_lines_and_shows_them_to_the_text_model() -> None:
    vision, llm = ScriptedVision("TÓM TẮT: Ảnh mã VietQR."), ScriptedLlm(transfer())
    res = await service(vision, llm).understand(request(image=True, qr=[VIETQR]))
    assert res.image is not None and res.image.status == "OK"
    assert res.image.description is not None and res.image.description.splitlines()[0] == "TÓM TẮT: Ảnh mã VietQR."
    assert res.image.description.splitlines()[1].startswith("[QR 1 – VietQR chuyển tiền, tĩnh, hợp lệ] BIN 970436")
    assert "[QR 1 – VietQR" in llm.calls[0]["messages"][-1].content.split("<current_turn>")[1]
    assert res.meta.prompts["understand_image"] == "understand_image.v1"


async def test_slow_image_read_fails_the_turn_without_a_text_call() -> None:  # IMP-38
    llm = ScriptedLlm(transfer())
    res = await service(ScriptedVision(delay_s=0.5), llm, limits=Limits(total_timeout_s=0.05)).understand(request(image=True, qr=[VIETQR]))
    assert res.image is not None and res.image.status == "TIMEOUT" and res.image.description is None
    assert (res.intent, res.relation, res.change_type, res.fields) == ("unknown", "other", "none", {})
    assert llm.calls == []


async def test_one_total_budget_covers_the_image_read_and_the_text_call() -> None:  # IMP-55
    # each call alone fits in the budget, the two together do not: the time left after the image read is what the text call gets
    with pytest.raises(AiTimeout):
        await service(ScriptedVision(delay_s=0.15), ScriptedLlm(transfer(), delay_s=0.15),
                      limits=Limits(total_timeout_s=0.25)).understand(request(image=True))


async def test_a_long_image_read_inside_the_total_budget_is_not_a_timeout() -> None:  # IMP-55: no separate image budget
    res = await service(ScriptedVision(delay_s=0.15), ScriptedLlm(transfer()), limits=Limits(total_timeout_s=1.0)).understand(request(image=True))
    assert res.image is not None and res.image.status == "OK"


async def test_vision_error_is_an_image_error_not_an_http_error() -> None:
    res = await service(ScriptedVision(error=ModelUnavailable("503")), ScriptedLlm(transfer())).understand(request(image=True))
    assert res.image is not None and res.image.status == "ERROR" and res.fields == {}


async def test_an_image_irrelevant_to_the_intent_loses_only_its_candidates() -> None:  # IMP-44, IMP-47
    llm = ScriptedLlm(transfer(fields={**TEXT_AMOUNT, **IMAGE_ACCOUNT}, image_relevant=False))
    res = await service(ScriptedVision("TÓM TẮT: Ảnh chân dung một người."), llm).understand(request(image=True))
    assert res.image is not None and res.image.status == "NOT_A_DOCUMENT"
    assert res.image.description == "TÓM TẮT: Ảnh chân dung một người." and set(res.fields) == {"amount"}


async def test_an_irrelevant_image_alone_is_unknown_and_not_a_document() -> None:  # IMP-47 (chat-service: TB-91, counts toward 3)
    llm = ScriptedLlm({"intent": "unknown", "relation": "new", "image_relevant": False})
    res = await service(ScriptedVision("TÓM TẮT: Ảnh phong cảnh."), llm).understand(request("", image=True))
    assert (res.intent, res.image.status if res.image else None) == ("unknown", "NOT_A_DOCUMENT")


async def test_a_decoded_vietqr_keeps_the_image_a_document() -> None:
    res = await service(llm=ScriptedLlm(transfer(image_relevant=False))).understand(request(image=True, qr=[VIETQR]))
    assert res.image is not None and res.image.status == "OK"


async def test_the_vision_prompt_does_not_judge_the_image_for_a_business() -> None:  # IMP-47
    vision = ScriptedVision("TÓM TẮT: Ảnh không có thông tin chuyển tiền.")
    res = await service(vision, ScriptedLlm(transfer())).understand(request(image=True))
    assert res.image is not None and res.image.status == "OK"  # only the text model's image_relevant decides


async def test_only_the_chosen_intents_slots_and_refs_are_kept() -> None:  # classification guard (IMP-47)
    llm = ScriptedLlm({"intent": "faq.answer", "relation": "other", "change_type": "fill", "fields": TEXT_AMOUNT,
                       "faq_query": "Phí chuyển tiền là bao nhiêu?"})
    res = await service(llm=llm).understand(request("phí chuyển cho mẹ bao nhiêu"))
    assert (res.intent, res.fields, res.change_type) == ("faq.answer", {}, "none")
    assert res.faq_query == "Phí chuyển tiền là bao nhiêu?"
    transfer_res = await service(llm=ScriptedLlm(transfer(faq_query="x"))).understand(request())
    assert transfer_res.faq_query is None and transfer_res.fields["amount"][0].value == 300000
    assert (await service(llm=ScriptedLlm(transfer(needs=["fee"]))).understand(request())).needs == []  # IMP-72


async def test_needs_follow_their_intents_and_are_lenient() -> None:  # IMP-72
    faq = ScriptedLlm({"intent": "faq.answer", "faq_query": "Phí chuyển khoản?",
                       "needs": ["fee", "nonsense", "fee", 3, "card", "promotion", "howto", "gold"]})
    res = await service(llm=faq).understand(request("phí chuyển khoản"))
    assert res.needs == ["fee", "card", "promotion", "howto"]  # known values, in order, no duplicates, at most four
    acc = ScriptedLlm({"intent": "account.inquiry", "faq_query": "Số dư của tôi?", "needs": ["balance"]})
    res = await service(llm=acc).understand(request("số dư", enabled=["account.inquiry", "unknown"]))
    assert res.needs == ["balance"] and res.faq_query == "Số dư của tôi?"
    bad = ScriptedLlm({"intent": "account.inquiry", "needs": "balance"})
    res = await service(llm=bad).understand(request("x", enabled=["account.inquiry", "unknown"]))
    assert res.needs == []


async def test_intent_outside_the_enabled_list_becomes_unknown() -> None:
    res = await service(llm=ScriptedLlm({"intent": "handoff.agent", "relation": "new"})).understand(request("gặp nhân viên"))
    assert res.intent == "unknown"


async def test_slow_or_limited_text_model_is_an_http_error() -> None:
    with pytest.raises(AiTimeout):
        await service(llm=ScriptedLlm(transfer(), delay_s=0.5), limits=Limits(total_timeout_s=0.05)).understand(request())
    with pytest.raises(RateLimited):
        await service(llm=ScriptedLlm(error=ModelRateLimited("429"))).understand(request())


async def test_image_size_and_encoding_are_checked_before_any_model_call() -> None:
    vision = ScriptedVision()
    with pytest.raises(ImageTooLarge):
        await service(vision, limits=Limits(max_image_base64_bytes=16)).understand(request(image=True, b64="A" * 64))
    with pytest.raises(BadRequest):
        await service(vision).understand(request(image=True, b64="not base64!"))
    assert vision.calls == []


async def test_shield_findings_fill_safety() -> None:
    res = await service(shield=ScriptedShield(ShieldResult(document_attack=True)), llm=ScriptedLlm(transfer())).understand(request(image=True))
    assert (res.safety.prompt_attack, res.safety.location) == (True, "image")
    res = await service(shield=ScriptedShield(ShieldResult(text_attack=True, document_attack=True)), llm=ScriptedLlm(transfer())).understand(request())
    assert res.safety.location == "text"


async def test_a_qr_reading_by_the_model_is_not_returned() -> None:  # IMP-55: QR decoding is chat-service's alone
    llm = ScriptedLlm(transfer(qr_observed={"present": True, "printed_text_near_qr": "NGUYEN THI LAN"}))
    res = await service(llm=llm).understand(request(image=True, qr=[VIETQR]))
    assert res.image is not None and "qr_observed" not in res.image.model_dump()
    system = llm.calls[0]["messages"][0].content
    assert "qr_observed" not in system and res.meta.prompt_version == "understand.v4"


async def test_image_never_reaches_logs_or_debug() -> None:  # U8, Review Focus
    with capture_logs() as logs:
        res = await service(llm=ScriptedLlm(transfer())).understand(request(image=True), debug=True)
    assert res.debug is not None
    dumped = json.dumps(res.debug, ensure_ascii=False) + str(logs)
    assert TINY_PNG_B64 not in dumped and TINY_PNG_B64[:24] not in dumped


@pytest.mark.parametrize("slip", [
    {"relation": None},
    {"secondary": [{"intent": "faq.answer"}]},
    {"option_choice": {"index": "hai"}},
], ids=["null_relation", "secondary_without_query", "bad_option"])
async def test_a_small_model_slip_drops_only_the_broken_part(slip: dict[str, Any]) -> None:  # final review: no 422 for an optional slip
    llm = ScriptedLlm(transfer(**slip))
    res = await service(llm=llm).understand(request(image=True, qr=[VIETQR]))
    assert res.intent == "transfer.domestic" and res.fields["amount"][0].value == 300000 and len(llm.calls) == 1


async def test_a_bad_candidate_is_dropped_and_the_others_kept() -> None:  # never coerced: an empty field is asked (rule 2)
    fields = {"amount": [{"value": "500k", "evidence": "500k", "from": "text"},
                         {"value": 300000, "evidence": "300k", "from": "text", "confidence": 0.9}],
              "account_no": [{"value": 181003561026, "evidence": "0181003561026", "from": "image"}],
              "phone": [{"value": "0901234567", "evidence": "0901234567", "from": "text"}]}
    llm = ScriptedLlm(transfer(fields=fields))
    res = await service(llm=llm).understand(request())
    assert set(res.fields) == {"amount"} and [c.value for c in res.fields["amount"]] == [300000] and len(llm.calls) == 1


async def test_a_broken_reference_on_an_unknown_turn_does_not_fail_it() -> None:
    llm = ScriptedLlm({"intent": "unknown", "relation": "new", "option_choice": {"index": "bad"}})
    res = await service(llm=llm).understand(request("alo"))
    assert res.intent == "unknown" and res.option_choice is None and len(llm.calls) == 1


async def test_an_unexpected_vision_failure_is_an_image_error() -> None:  # IMP-38, final review
    res = await service(ScriptedVision(error=IndexError("no choices")), ScriptedLlm(transfer())).understand(request(image=True))
    assert res.image is not None and res.image.status == "ERROR" and res.meta.prompts == {"understand_image": "understand_image.v1"}


async def test_a_timed_out_image_read_is_still_traced() -> None:  # IMP-48
    res = await service(ScriptedVision(delay_s=0.5), ScriptedLlm(transfer()), limits=Limits(total_timeout_s=0.05)).understand(
        request(image=True), debug=True)
    assert res.meta.prompts == {"understand_image": "understand_image.v1"}
    assert res.debug is not None and res.debug["calls"][0]["error"] == "timeout"


def test_a_registry_section_without_its_prompt_fails_at_startup(tmp_path: Path) -> None:
    (tmp_path / "intents.v1.yaml").write_text("- intent_id: bill.pay\n  section: intent_bill_pay\n", encoding="utf-8")
    with pytest.raises(FileNotFoundError, match="intent_bill_pay"):
        UnderstandService(make_caps(), IntentCatalog(tmp_path), Limits())


async def test_language_sent_wins() -> None:
    res = await service(llm=ScriptedLlm(transfer(language="en"))).understand(request("Send 300k to mom", language="vi"))
    assert res.language == "vi"


async def test_language_detected_when_absent() -> None:
    res = await service(llm=ScriptedLlm(transfer(language="en"))).understand(request("Send 300k to mom"))
    assert res.language == "en"


async def test_language_defaults_to_vietnamese_when_nothing_says_otherwise() -> None:
    assert (await service(llm=ScriptedLlm(transfer())).understand(request())).language == "vi"


async def test_image_failure_keeps_requested_language() -> None:
    res = await service(ScriptedVision(error=TimeoutError()), ScriptedLlm(transfer())).understand(request(image=True, language="en"))
    assert res.image is not None and res.image.status == "TIMEOUT" and res.language == "en"

