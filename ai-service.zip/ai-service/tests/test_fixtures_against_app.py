"""The spec §7 fixtures run against the real app: with scripted models the app returns exactly the fixture's response;
with the fake adapters every fixture request is answered within the contract."""

import base64
import copy
import json
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from ai_service.api.app import create_app
from ai_service.config import Settings
from ai_service.contract import UnderstandResponse
from ai_service.contract.understand import QrIn
from ai_service.main import build_services
from ai_service.ports import ShieldResult
from ai_service.understand.limits import Limits
from ai_service.understand.qr_lines import qr_line

from .doubles import TINY_PNG_B64, ScriptedLlm, ScriptedShield, ScriptedVision, make_services
from .fixtures_util import ResolvedFixture, load_understand_fixtures

ALL = load_understand_fixtures()
URL = "/internal/ai/v1/understand"
MODEL_KEYS = ("intent", "language", "relation", "change_type", "fields", "option_choice", "source_account", "amount_ref",
              "objection", "secondary", "faq_query", "needs", "reason")
FORBIDDEN = {"phase", "tb_code", "transfer_request", "customer_id", "draft_status"}


def _with_image_bytes(request: dict[str, Any], b64: str = TINY_PNG_B64) -> dict[str, Any]:
    req = copy.deepcopy(request)
    if (req["message"].get("image") or {}).get("data_base64"):
        req["message"]["image"]["data_base64"] = b64
    return req


def _no_qr(text: str) -> list[str]:
    return [ln for ln in text.splitlines() if not ln.strip().startswith("[QR ")]


def _normal(body: dict[str, Any]) -> dict[str, Any]:
    out = UnderstandResponse.model_validate(body).model_dump(mode="json")
    out.pop("meta")
    out.pop("debug")
    return out


@pytest.mark.parametrize("fx", ALL, ids=lambda f: f.name)
def test_app_returns_the_fixture_response_for_scripted_models(fx: ResolvedFixture) -> None:
    want = fx.response
    img = want.get("image") or {}
    status = img.get("status", "OK")
    model_out = {k: want[k] for k in MODEL_KEYS if k in want}
    loc = (want.get("safety") or {}).get("location")
    llm = ScriptedLlm(model_out)
    vision = ScriptedVision("\n".join(_no_qr(img.get("description") or "TÓM TẮT: Ảnh.")), delay_s=1.0 if status == "TIMEOUT" else 0.0)
    services = make_services(vision, llm, ScriptedShield(ShieldResult(text_attack=loc == "text", document_attack=loc == "image")),
                             Limits(total_timeout_s=0.1))
    res = TestClient(create_app(services, Settings())).post(URL, json=_with_image_bytes(fx.request))
    assert res.status_code == 200, res.text
    got = res.json()
    got_n, want_n = _normal(got), _normal(want)
    got_img, want_img = got_n.pop("image") or {}, want_n.pop("image") or {}
    assert got_n == want_n
    assert got_img.get("status") == want_img.get("status") and "qr_observed" not in got_img
    if want_img.get("description"):
        qrs = [QrIn.model_validate(q) for q in fx.request["message"]["image"].get("qr", [])]
        assert _no_qr(got_img["description"]) == _no_qr(want_img["description"])
        assert [ln for ln in got_img["description"].splitlines() if ln.startswith("[QR ")] == [qr_line(q, i) for i, q in enumerate(qrs, 1)]
    if status == "TIMEOUT":
        assert llm.calls == []


@pytest.fixture(scope="module")
def fake_client() -> TestClient:
    return TestClient(create_app(build_services(Settings()), Settings()))


def _keys(node: Any) -> set[str]:
    if isinstance(node, dict):
        return set(node) | {k for v in node.values() for k in _keys(v)}
    if isinstance(node, list):
        return {k for v in node for k in _keys(v)}
    return set()


@pytest.mark.parametrize("fx", ALL, ids=lambda f: f.name)
def test_fake_mode_answers_every_fixture_within_the_contract(fx: ResolvedFixture, fake_client: TestClient) -> None:
    res = fake_client.post(URL, json=_with_image_bytes(fx.request))
    assert res.status_code == 200, res.text
    UnderstandResponse.model_validate(res.json())
    assert not (_keys(res.json()) & FORBIDDEN)  # U3


def test_fake_mode_reads_a_testdata_image_by_its_bytes(fake_client: TestClient) -> None:
    images = Path(__file__).resolve().parents[2] / "testdata" / "images"
    img = next(p for p in sorted(images.glob("*.jpg")) if (images / (p.stem + ".desc.txt")).exists())
    body = {"request_id": "req_9", "turn_id": "trn_9", "intents_enabled": ["transfer.domestic", "unknown"],
            "message": {"text": "", "image": {"image_id": "img_9", "media_type": "image/jpeg", "data_base64": base64.b64encode(img.read_bytes()).decode()}}}
    got = fake_client.post(URL, json=body).json()
    assert got["image"]["description"].startswith((images / (img.stem + ".desc.txt")).read_text(encoding="utf-8").strip())


def test_fake_mode_new_transfer_amount(fake_client: TestClient) -> None:
    fx = next(f for f in ALL if f.name == "01_vietqr_new_task")
    got = fake_client.post(URL, json=_with_image_bytes(fx.request)).json()
    assert json.dumps(got["fields"].get("amount"), ensure_ascii=False) == '[{"value": 500000, "evidence": "500k", "from": "text"}]'
