"""contracts/fixtures/qr/vietqr.json carries the group-H shape (`qr_in`) that chat-service sends for each decoded QR."""

import json
from pathlib import Path
from typing import Any

import pytest

from ai_service.contract.understand import QrIn

CASES: list[dict[str, Any]] = json.loads((Path(__file__).resolve().parents[2] / "contracts" / "fixtures" / "qr" / "vietqr.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("case", CASES, ids=lambda c: c["name"])
def test_qr_fixture_has_a_valid_qr_in(case: dict[str, Any]) -> None:
    QrIn.model_validate(case["qr_in"])
