"""Loads contracts/fixtures/understand/*.json (JSON merge patches on a base, RFC 7386)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

DIR = Path(__file__).resolve().parents[2] / "contracts" / "fixtures" / "understand"


@dataclass(frozen=True)
class ResolvedFixture:
    name: str
    request: dict[str, Any]
    response: dict[str, Any]
    expect: str
    expect_rejected: tuple[str, ...] = ()  # parts chat-service must drop, e.g. "fields.account_no", "option_choice"


def merge_patch(target: Any, patch: Any) -> Any:
    if not isinstance(patch, dict):
        return patch
    out = dict(target) if isinstance(target, dict) else {}
    for key, value in patch.items():
        if value is None:
            out.pop(key, None)
        else:
            out[key] = merge_patch(out.get(key), value)
    return out


def _read(name: str) -> dict[str, Any]:
    data: dict[str, Any] = json.loads((DIR / f"{name}.json").read_text(encoding="utf-8"))
    return data


def _request(name: str, base: dict[str, Any]) -> dict[str, Any]:
    raw = _read(name)
    start = _request(raw["request_extends"], base) if raw.get("request_extends") else base
    result: dict[str, Any] = merge_patch(start, raw.get("request", {}))
    return result


def load_understand_fixtures() -> list[ResolvedFixture]:
    base_req, base_res = _read("_base.request"), _read("_base.response")
    out = []
    for path in sorted(p for p in DIR.glob("*.json") if not p.name.startswith("_")):
        raw = _read(path.stem)
        out.append(ResolvedFixture(path.stem, _request(path.stem, base_req), merge_patch(base_res, raw.get("response", {})), raw["expect"],
                                   tuple(raw.get("expect_rejected", []))))
    return out
