from typing import Any

from fastapi.testclient import TestClient

from ai_service.api.app import create_app
from ai_service.config import Settings
from ai_service.main import build_services, create
from ai_service.ports import ModelRateLimited

from .doubles import TINY_PNG_B64, ScriptedLlm, make_services

URL = "/internal/ai/v1"
BODY = {"request_id": "req_1", "turn_id": "trn_1", "intents_enabled": ["transfer.domestic", "unknown"], "message": {"text": "chuyển 300k"}}
OUT = {"intent": "transfer.domestic", "relation": "new", "change_type": "fill",
       "fields": {"amount": [{"value": 300000, "evidence": "300k", "from": "text"}]}}


def client(llm: ScriptedLlm | None = None, **settings: Any) -> TestClient:
    return TestClient(create_app(make_services(llm=llm or ScriptedLlm(OUT)), Settings(**settings)))


def test_understand_answers_200_with_from_aliased() -> None:
    res = client().post(f"{URL}/understand", json=BODY)
    assert res.status_code == 200 and res.json()["fields"]["amount"][0]["from"] == "text" and res.json()["request_id"] == "req_1"


def test_internal_key_is_enforced_when_configured() -> None:  # Review Focus
    llm = ScriptedLlm(OUT)
    c = client(llm, ai_internal_key="secret")
    for headers in ({}, {"X-Internal-Key": "wrong"}):
        res = c.post(f"{URL}/understand", json=BODY, headers=headers)
        assert res.status_code == 401 and res.json()["error"]["code"] == "AI_UNAUTHORIZED"
    assert llm.calls == []
    assert c.post(f"{URL}/understand", json=BODY, headers={"X-Internal-Key": "secret"}).status_code == 200


def test_an_enabled_intent_unknown_to_the_registry_is_400_before_any_model_call() -> None:  # IMP-57
    llm = ScriptedLlm(OUT)
    res = client(llm).post(f"{URL}/understand", json={**BODY, "intents_enabled": ["transfer.domestic", "bill.pay", "unknown"]})
    assert res.status_code == 400
    err = res.json()["error"]
    assert err["code"] == "AI_BAD_REQUEST" and err["retryable"] is False and "bill.pay" in err["message"] and err["request_id"] == "req_1"
    assert llm.calls == []


def test_healthz_needs_no_key() -> None:
    assert client(ai_internal_key="secret").get("/healthz").json() == {"status": "ok", "llm_provider": "fake"}


def test_ai_errors_carry_status_code_and_request_id() -> None:
    res = client(ScriptedLlm(error=ModelRateLimited("429"))).post(f"{URL}/understand", json=BODY)
    assert res.status_code == 429
    assert res.json() == {"error": {"code": "AI_RATE_LIMITED", "message": "429", "retryable": True, "request_id": "req_1"}}
    res = client(ScriptedLlm("not json")).post(f"{URL}/understand", json=BODY)
    assert res.status_code == 422 and res.json()["error"]["code"] == "AI_OUTPUT_INVALID"


def test_big_image_is_413() -> None:
    from ai_service.understand.limits import Limits

    app = create_app(make_services(llm=ScriptedLlm(OUT), limits=Limits(max_image_base64_bytes=8)), Settings())
    body = {**BODY, "message": {"text": "", "image": {"image_id": "img_1", "media_type": "image/png", "data_base64": TINY_PNG_B64, "qr": []}}}
    res = TestClient(app).post(f"{URL}/understand", json=body)
    assert res.status_code == 413 and res.json()["error"]["code"] == "AI_IMAGE_TOO_LARGE"


def test_debug_needs_both_the_setting_and_the_header() -> None:
    assert client().post(f"{URL}/understand", json=BODY, headers={"X-Debug-Trace": "1"}).json()["debug"] is None
    on = client(ai_debug_trace=True)
    assert on.post(f"{URL}/understand", json=BODY).json()["debug"] is None
    assert on.post(f"{URL}/understand", json=BODY, headers={"X-Debug-Trace": "1"}).json()["debug"]["calls"][0]["use_case"] == "sami.understand"


def test_summarize_route() -> None:
    c = client(ScriptedLlm("Khách muốn gặp nhân viên."))
    summary = {"request_id": "req_3", "purpose": "handoff", "turns": [{"role": "user", "text": "alo"}]}
    assert c.post(f"{URL}/summarize", json=summary).json()["summary"] == "Khách muốn gặp nhân viên."


def test_each_request_leaves_one_trace_line() -> None:  # IMP-48: request_id -> the prompts it used
    from structlog.testing import capture_logs

    with capture_logs() as logs:
        client().post(f"{URL}/understand", json=BODY)
        client(ScriptedLlm(error=ModelRateLimited("429"))).post(f"{URL}/understand", json=BODY)
    done = [e for e in logs if e["event"] == "request_done"]
    assert len(done) == 2
    assert (done[0]["request_id"], done[0]["turn_id"], done[0]["endpoint"], done[0]["status"]) == ("req_1", "trn_1", "understand", 200)
    assert done[0]["prompts"]["understand"] == "understand.v4" and done[0]["prompts"]["intents"] == "intents.v6"
    assert done[0]["intent"] == "transfer.domestic" and done[0]["image_status"] is None
    assert (done[1]["status"], done[1]["error"], done[1]["request_id"]) == (429, "AI_RATE_LIMITED", "req_1")


def test_composition_root_builds_the_fake_service() -> None:
    services = build_services(Settings())
    res = TestClient(create_app(services, Settings())).post(f"{URL}/understand", json=BODY)
    assert res.status_code == 200 and res.json()["meta"]["models"]["text"] == "fake-text"
    assert create().title == "Sami ai-service"


def test_a_400_never_echoes_the_image() -> None:  # final review: chat-service writes this body to its error log (U8)
    body: dict[str, Any] = {k: v for k, v in BODY.items() if k != "request_id"}
    body["message"] = {"text": "", "image": {"image_id": "img_1", "media_type": "image/png", "data_base64": TINY_PNG_B64, "qr": []}}
    res = client().post(f"{URL}/understand", json=body)
    assert res.status_code == 400 and TINY_PNG_B64[:12] not in res.text and "request_id" in res.json()["error"]["message"]


def test_an_unexpected_error_is_a_503_with_the_contract_body_and_a_trace_line() -> None:
    from structlog.testing import capture_logs

    with capture_logs() as logs:
        res = client(ScriptedLlm(error=RuntimeError("bug"))).post(f"{URL}/understand", json=BODY)
    assert res.status_code == 503
    assert res.json() == {"error": {"code": "AI_UNAVAILABLE", "message": "internal error", "retryable": True, "request_id": "req_1"}}
    assert [(e["status"], e["error"]) for e in logs if e["event"] == "request_done"] == [(503, "AI_UNAVAILABLE")]


def test_rejected_requests_leave_a_trace_line_too() -> None:  # IMP-48 (3): one request_done per request
    from structlog.testing import capture_logs

    with capture_logs() as logs:
        client(ai_internal_key="secret").post(f"{URL}/understand", json=BODY, headers={"X-Request-Id": "req_h"})
        client().post(f"{URL}/understand", json={"x": 1}, headers={"X-Request-Id": "req_h"})
    done = [(e["status"], e["error"], e["request_id"], e["endpoint"]) for e in logs if e["event"] == "request_done"]
    assert done == [(401, "AI_UNAUTHORIZED", "req_h", "understand"), (400, "AI_BAD_REQUEST", "req_h", "understand")]
