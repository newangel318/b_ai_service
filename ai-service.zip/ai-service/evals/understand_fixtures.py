"""/understand fixture eval: posts the spec §7 text fixtures to the app with the configured models and scores each answer
against the fixture's response, key by key. Evidence wording, provenance and free-text reasons are not scored.

    uv run python -m evals.understand_fixtures --report ../out/understand_eval.md [--env-file ../.env]

Skipped (listed in the report): image fixtures – their image is a placeholder – and the negative fixtures ``n*``, whose
response is scripted wrong model output that chat-service must reject. With LLM_PROVIDER=fake the numbers check the
harness, not a model.
"""

from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from collections.abc import Callable, Iterator, Sequence
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

FIELD_NAMES = ("bank", "account_no", "amount", "reference", "recipient_name_on_image")  # contract FieldName
# Each field is its own key: a junk note must not hide a right (or wrong) amount or account.
SCORED = ("intent", "relation", "change_type", *(f"fields.{n}" for n in FIELD_NAMES), "payee", "option_choice",
          "source_account", "amount_ref", "objection", "secondary")
UNSCORED = {"evidence", "from", "reason", "query", "claim"}  # wording / provenance, not the decision
URL = "/internal/ai/v1/understand"


def _strip(v: Any) -> Any:
    if isinstance(v, dict):
        return {k: _strip(x) for k, x in v.items() if k not in UNSCORED}
    if isinstance(v, list):
        return sorted((_strip(x) for x in v), key=lambda x: json.dumps(x, sort_keys=True, ensure_ascii=False))
    if isinstance(v, str):
        return " ".join(v.split()).casefold()  # "  Tiền  chợ " = "tiền chợ"
    return v


def project(resp: dict[str, Any]) -> dict[str, Any]:
    out = {}
    fields = resp.get("fields") or {}
    for k in SCORED:
        v = _strip(fields.get(k.removeprefix("fields.")) if k.startswith("fields.") else resp.get(k))
        out[k] = None if v in (None, {}, [], "") else v
    return out


def score(expected: dict[str, Any], got: dict[str, Any]) -> list[str]:
    want, have = project(expected), project(got)
    return [k for k in SCORED if want[k] != have[k]]


def skip_reason(fx: Any) -> str | None:
    if fx.name.startswith("n"):
        return "negative fixture (scripted wrong model output for chat-service to reject)"
    if (fx.request.get("message") or {}).get("image"):
        return "image fixture (the image is a placeholder)"
    return None


@dataclass
class FixtureResult:
    name: str
    skipped: str | None
    status: int = 0
    mismatches: list[str] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)


def evaluate(post: Callable[[dict[str, Any]], tuple[int, dict[str, Any]]], fixtures: Sequence[Any]) -> list[FixtureResult]:
    results = []
    for fx in fixtures:
        reason = skip_reason(fx)
        if reason:
            results.append(FixtureResult(fx.name, reason))
            continue
        req = copy.deepcopy(fx.request)
        req["request_id"] = f"req_{fx.name}"
        status, body = post(req)
        if status != 200:
            results.append(FixtureResult(fx.name, None, status, [f"status {status}"]))
            continue
        results.append(FixtureResult(fx.name, None, status, score(fx.response, body), body.get("meta") or {}))
    return results


def render(results: list[FixtureResult], provider: str) -> str:
    scored = [r for r in results if r.skipped is None]
    passed = sum(1 for r in scored if not r.mismatches)
    prompts = sorted({str(r.meta.get("prompt_version")) for r in scored if r.meta.get("prompt_version")})
    models = sorted({str(m) for r in scored for m in (r.meta.get("models") or {}).values()})
    lines = ["# /understand fixture eval", "", f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')}", "",
             f"- LLM provider: `{provider}`", f"- Prompt versions: {', '.join(f'`{p}`' for p in prompts) or 'n/a'}",
             f"- Models: {', '.join(f'`{m}`' for m in models) or 'n/a'}", ""]
    if provider == "fake":
        lines += ["> **Fake mode.** The fake models are heuristics: these numbers check the harness, not a model.", ""]
    lines += [f"Scored fixtures passed: **{passed}/{len(scored)}**", "", "| Key | Correct |", "|---|---|"]
    ok_status = [r for r in scored if r.status == 200]
    for k in SCORED:
        lines.append(f"| {k} | {sum(1 for r in ok_status if k not in r.mismatches)}/{len(ok_status)} |")
    lines += ["", "| Fixture | Result |", "|---|---|"]
    for r in scored:
        lines.append(f"| {r.name} | {'ok' if not r.mismatches else 'differs: ' + ', '.join(r.mismatches)} |")
    lines += ["", "Skipped:", ""] + [f"- {r.name}: {r.skipped}" for r in results if r.skipped]
    return "\n".join(lines) + "\n"


@contextmanager
def app_poster(app: Any, headers: dict[str, str]) -> Iterator[Callable[[dict[str, Any]], tuple[int, dict[str, Any]]]]:
    """One TestClient session for every request: one event loop, so the model SDK's connection pool stays usable.
    A server exception is a scored 500, not the end of the run."""
    from fastapi.testclient import TestClient

    with TestClient(app, raise_server_exceptions=False) as client:

        def post(req: dict[str, Any]) -> tuple[int, dict[str, Any]]:
            r = client.post(URL, json=req, headers=headers)
            try:
                body = r.json()
            except ValueError:
                body = {"error": r.text[:200]}
            return r.status_code, body

        yield post


def main(argv: list[str] | None = None) -> int:
    from ai_service.api.app import create_app
    from ai_service.config import Settings
    from ai_service.main import build_services
    from tests.fixtures_util import load_understand_fixtures

    ap = argparse.ArgumentParser()
    ap.add_argument("--report", default=str(Path(__file__).resolve().parents[2] / "out" / "understand_eval.md"))
    ap.add_argument("--env-file", default=None, help="dotenv file with the model settings (the shell environment wins)")
    a = ap.parse_args(argv)
    settings = Settings(_env_file=a.env_file) if a.env_file else Settings()  # type: ignore[call-arg]
    headers = {"X-Internal-Key": settings.ai_internal_key} if settings.ai_internal_key else {}
    with app_poster(create_app(build_services(settings), settings), headers) as post:
        results = evaluate(post, load_understand_fixtures())
    Path(a.report).parent.mkdir(parents=True, exist_ok=True)
    Path(a.report).write_text(render(results, settings.llm_provider), encoding="utf-8")
    scored = [r for r in results if r.skipped is None]
    print(f"Report: {a.report}\nScored: {len(scored)}  passed: {sum(1 for r in scored if not r.mismatches)}")
    return 1 if any(r.status != 200 for r in scored) else 0


if __name__ == "__main__":
    sys.exit(main())
